<?php
session_start();
require '../../../../common/connection.php';

$mrm_id = $_POST['mrm_id'];
$snf = $_POST['snf'];
$rate = $_POST['rate'];

 // echo $rate."	".$mrm_id."		".$snf;


// $sql = "UPDATE `milk_rate_master` SET 
//        `mrm_snf` = '$snf', 
//        `mrm_rate` = '$rate'
//   where 'mrm_id' = '$mrm_id' ";


$sql = "UPDATE milk_rate_master SET mrm_snf='".$snf."',mrm_rate='".$rate."' WHERE mrm_id = '".$mrm_id."' ";
$result = $conn->query($sql);
echo $result;

// if($result>0){
// 	echo "SNF Updated";
// }
// else{
// 	echo "SNF Not Updated";
// }

$conn->close();

?>

