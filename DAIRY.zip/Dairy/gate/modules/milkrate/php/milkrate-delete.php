<?php
session_start();
require '../../../../common/connection.php';

$id = $_POST['id'];

$sql = "UPDATE milk_rate_master SET mrm_status=1 WHERE mrm_id = $id ";
$result = $conn->query($sql);

if($result){
	echo "SNF Deleted";
}
else{
	echo "SNF Not Deleted";
}

$conn->close();

?>

