<?php
session_start();
require '../../../../common/connection.php';

$i=0;

$sqlCount="SELECT count(*) as total from milk_rate_master";
$result = $conn->query($sqlCount);
$data=$result->fetch_assoc();
$count=$data['total'];

$sql="select * from milk_rate_master where mrm_status = 0";
$result = $conn->query($sql);

// if ($result->num_rows > 0) {
//     while($row = $result->fetch_assoc()) {
// 		echo "<tr><td class='text-center'>" . ++$i."</td><td class='text-center'>" . $row["mrm_snf"].".0"."<span class='id' style='display:none;'>".$row["mrm_id"]."</span>". "</td><td class='text-center'>" . $row["mrm_rate"].".00"."<span class='mrm_snf' style='display:none;'>".$row["mrm_snf"]."</span>"."</td><td class='text-center'>" . $row["mrm_created_at"]."<span class='mrm_rate' style='display:none;'>".$row["mrm_rate"]."</span>". "</td><td class='text-center' > <i style='cursor:pointer;' class='fa fa-pencil-square-o' ></i> &nbsp; <i style='cursor:pointer;' class='fa fa-trash-o'></i>
//             </td></tr>";
//     }
// } else {
//     echo "0 results";
// }

$cars = array
  (
  array("Volvo",22,18),
  array("BMW",15,13),
  array("Saab",5,2)
  );


	$list = array();
	// array_push($list,array("MRF",22,18),array("RBK",15,13),array("SOLAR",5,2));


if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		array_push($list,array(++$i,$row["mrm_snf"].".0"."<span class='id' style='display:none;'>".$row["mrm_id"]."</span>",$row["mrm_rate"].".00"."<span class='mrm_snf' style='display:none;'>".$row["mrm_snf"]."</span>",$row["mrm_created_at"]."<span class='mrm_rate' style='display:none;'>".$row["mrm_rate"]."</span>","<i style='cursor:pointer;' class='fa fa-pencil-square-o' ></i> &nbsp; <i style='cursor:pointer;' class='fa fa-trash-o'></i>"));

      
      // array_push($list,array(++$i,$row["mrm_snf"].".0"."<span class='id' style='display:none;'>".$row["mrm_id"]."</span>",$row["mrm_rate"].".00"."<span class='mrm_snf' style='display:none;'>".$row["mrm_snf"]."</span>",$row["mrm_created_at"]."<span class='mrm_rate' style='display:none;'>".$row["mrm_rate"]."</span>","<button class='btn btn-primary btn-xs'><i class='fa fa-pencil'></i></button> <button class='btn btn-danger btn-xs'><i class='fa fa-trash-o'></i></button>"));
    }
} else {
    echo "0 results";
}


$myJSON = json_encode($list);
  echo $myJSON;




// if ($result->num_rows > 0) {
// 	// echo "[";
//     while($row = $result->fetch_assoc()) {
//     	$i++;
//     	if($count==$i){
//     		// echo "[".".$row["mrm_snf"]."."]";
//     		echo '["'.$row["mrm_snf"].'","'.$row["mrm_rate"].'","'.$row["mrm_created_at"].'"]';
//     	}
//     	else{
//     		echo '["'.$row["mrm_snf"].'","'.$row["mrm_rate"].'","'.$row["mrm_created_at"].'"],';
//     	}
		
//     }
//     // echo "];";
// } else {
//     echo "0 results";
// }
$conn->close();
?>