<?php
session_start();
require '../../../../common/connection.php';


$snf=$_POST["snf"];
$rate=$_POST["rate"];



$sqlchk = "SELECT mrm_snf from milk_rate_master where mrm_snf='" .$snf. "' and  mrm_status=0";
$result = $conn->query($sqlchk);

			if ($result->num_rows > 0) {
				echo "This SNF already added..!";
			}
			else{
					$sql = "INSERT milk_rate_master(mrm_snf,mrm_rate) VALUES ('".$snf."','".$rate."')";
					$insert = $conn->query($sql);
					if($insert)
						echo "ok";
					else
						echo "not ok";
			}
$conn->close();
?>