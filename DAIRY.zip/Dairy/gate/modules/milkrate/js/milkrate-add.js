$(document).ready(function(e){

	localStorage.removeItem("mrm_edit_details");              

	$("#id_saveData").click(function(e) {

		
		var snf,rate;
		snf=$("#id_snf").val();
		rate=$("#id_rate").val();
		

		if(snf==null || snf=='' || snf==undefined){
		  alert('Please Select snf')
		  $('#id_snf').focus();
		}
		else if(rate=="" || rate==undefined || rate==null){
		  alert('Please Enter rate');
		  
		  $('#id_rate').focus();
		}		
		else
		{
		  $.ajax({
		        type: 'POST',
		        url: '../php/milkrate-add.php',
		        data: {snf : snf, rate : rate}        
		   })
		  .done(function(response){ 

		  		// alert(response);
		  
		        if(response == "ok"){
		        alert("SNF Added Successfully..!");
				location.reload();
		   }else{
		        alert("SNF already exist -(:");
		        
		        }

		   })
		   .fail(function(response) {

		   		console.log("Oop's Something went wrong..!");
		   		alert(response);
				// Lobibox.alert('error',
				// {
				// 	msg: response
				// });
		   });
		      
		      return false;
		}
	});


});