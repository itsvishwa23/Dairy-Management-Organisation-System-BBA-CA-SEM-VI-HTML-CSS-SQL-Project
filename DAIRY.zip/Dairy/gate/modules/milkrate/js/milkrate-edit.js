$(document).ready(function(e){

  if (localStorage.getItem("mrm_edit_details") === null) {
    alert("Invalid Action");
    window.location="milkrate-list.html";
  }



  var json = localStorage.getItem("mrm_edit_details");
  var mrm_edit_details = JSON.parse(json);
  var mrm_id = mrm_edit_details.mrm_id;
  var mrm_snf = mrm_edit_details.mrm_snf;
  var mrm_rate = mrm_edit_details.mrm_rate;

  $("#id_snf").val(mrm_snf);
  $('#id_rate').val(mrm_rate)



    $("#id_saveData").click(function(e) {

    
    var snf,rate;
    snf=$("#id_snf").val();
    rate=$("#id_rate").val();
    

    if(snf==null || snf=='' || snf==undefined){
      alert('Please Select snf')
      $('#id_snf').focus();
    }
    else if(rate=="" || rate==undefined || rate==null){
      alert('Please Enter rate');
      
      $('#id_rate').focus();
    }   
    else
    {
      $.ajax({
            type: 'POST',
            url: '../php/milkrate-edit.php',
            data: {mrm_id : mrm_id, snf : snf, rate : rate}        
       })
      .done(function(response){ 

        // var res = "SNF Updated";

          // alert(response);
          // console.log(response);
      
            if(response>0){

              localStorage.removeItem("mrm_edit_details");              
              alert("SNF Updated..!");
              window.location="milkrate-list.html";
              
            }
            else{
              alert("SNF not Updated -(:");
            
            }

       })
       .fail(function(response) {

          console.log("Oop's Something went wrong..!");
          alert(response);
        // Lobibox.alert('error',
        // {
        //  msg: response
        // });
       });
          
          return false;
    }
  });

    $("#id_back").click(function(e) {
      window.location="milkrate-list.html";
    });



});