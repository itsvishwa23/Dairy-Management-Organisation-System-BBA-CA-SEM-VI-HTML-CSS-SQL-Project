$(document).ready(function(e){

  localStorage.removeItem("mrm_edit_details");              

	$.ajax({
          type: 'POST',
          url: '../php/milkrate-list.php'
          
  	})
  .done(function(data){ 
    // $("#id_list").html(data);
    // $("#example").html(data);
    
    var dataSet=JSON.parse(data);
    console.log(JSON.parse(data));
    // console.log(data);
    var dataSet2 = [["Tiger Nixon","System Architect","Edinburgh"],
      ["Garrett Winters","Accountant","Tokyo"],
      ["Ashton Cox","Junior Technical Author","San Francisco"]];

      // console.log(dataSet);

    $('#id_list').DataTable( {
        data: dataSet,
        columns: [
            {"className": "dt-center", title: "SR NO" },
            {"className": "dt-center", title: "SNF" },
            {"className": "dt-center", title: "RATE" },
            {"className": "dt-center", title: "Created Date" },
            {"className": "dt-center", title: "Action" }
        ]
    } );

    // alert(data);
  })
  .fail(function(data) {
    alert(data);
  });  

  $("#id_list").on("click", ".fa-pencil-square-o", (function (ev){
    
    
    var id,mrm_snf,mrm_rate;
    id = $(this).parent().parent().children().children(".id").html();
    mrm_snf = $(this).parent().parent().children().children(".mrm_snf").html();
    mrm_rate = $(this).parent().parent().children().children(".mrm_rate").html();
    
    var mrm_edit_details = {"mrm_id":id,"mrm_snf":mrm_snf,"mrm_rate":mrm_rate};
    var myJSON = JSON.stringify(mrm_edit_details);    
    localStorage.setItem("mrm_edit_details", myJSON);

    if (localStorage.getItem("mrm_edit_details") != null) {
	  window.location="milkrate-edit.html";
	}

    // $.ajax({
    //   type: 'POST',
    //   url: 'Employee/model/employee-delete.php',
    //   data: {id:id}
    // })
    // .done(function(data){
    // alert(data); 
    // location.reload();
      
    // })
    // .fail(function(data) {
    //   alert(data);
    // });
    }));



  $("#id_list").on("click", ".fa-trash-o", (function (ev){
    
    
    
    var id;
    id = $(this).parent().parent().children().children(".id").html();

    if (id != null || id !='' || id !=undefined) {
    	if (confirm("Are you sure want to delete this SNF?")) {

    
			    $.ajax({
			      type: 'POST',
			      url: '../php/milkrate-delete.php',
			      data: {id:id}
			    })
			    .done(function(data){
			    	alert(data); 
			    	location.reload();			      
			    })
			    .fail(function(data) {
			      alert(data);
			    });
		}
    }
    else{
    	alert("Invalid Action..!");
    }
    }));



});