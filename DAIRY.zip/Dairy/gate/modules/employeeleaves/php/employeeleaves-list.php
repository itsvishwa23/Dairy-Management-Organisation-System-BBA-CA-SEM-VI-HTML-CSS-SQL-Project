<?php
session_start();
require '../../../../common/connection.php';

$i=0;
$sql="SELECT * FROM employee_leaves el LEFT OUTER JOIN employee_master em ON el.el_em_id = em.em_id where el_status = 0";
$result = $conn->query($sql);

$list = array();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		array_push($list,array(++$i,$row["el_id"]."<span class='el_id' style='display:none;'>".$row["el_id"]."</span>",$row["em_first_name"]."<span class='em_first_name' style='display:none;'>".$row["em_first_name"]."</span>",$row["em_last_name"]."<span class='em_last_name' style='display:none;'>".$row["em_last_name"]."</span>",$row["el_date"]."<span class='el_date' style='display:none;'>".$row["el_date"]."</span>",$row["em_mobile"]."<span class='em_mobile' style='display:none;'>".$row["em_mobile"]."</span>",$row["em_address"]."<span class='em_address' style='display:none;'>".$row["em_address"]."</span>",$row["em_created_at"]."<span class='em_created_at' style='display:none;'>".$row["em_created_at"]."</span>","<i style='cursor:pointer;' class='fa fa-pencil-square-o' ></i> &nbsp; <i style='cursor:pointer;' class='fa fa-trash-o'></i>"));
    }
} else {
    echo "0 results";
}


$myJSON = json_encode($list);
echo $myJSON;
$conn->close();
?>