<?php
session_start();
require '../../../../common/connection.php';
 
$el_em_id=$_POST["el_em_id"];
$el_date=$_POST["el_date"];

$sqlchk = "SELECT el_date from employee_leaves where el_em_id='" .$el_em_id. "' and  el_date='" .$el_date. "'";
$result = $conn->query($sqlchk);

if($result->num_rows > 0) {
	echo "This Leaves is already marked..!";
}
else{

$sql = "INSERT employee_leaves(el_date,el_em_id) VALUES ('".$el_date."','".$el_em_id."')";

$insert = $conn->query($sql);
echo $insert;

}
// if($insert == 1){

// 	$sql = "SELECT sm_milk_available from storage_master where sm_id='" .$el_sm_id. "'";
// 	$result = $conn->query($sql);
// 	$row = $result->fetch_assoc();
// 	$sm_milk_available = $row["sm_milk_available"] + $el_date;

// 	$sql = "UPDATE storage_master SET sm_available='".$sm_available."',sm_milk_available='".$sm_milk_available."' WHERE sm_id = '".$el_sm_id."' ";
// 	$result = $conn->query($sql);
// 	echo $result;
// }			
$conn->close();
?>