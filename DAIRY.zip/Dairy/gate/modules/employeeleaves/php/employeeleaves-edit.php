<?php
session_start();
require '../../../../common/connection.php';
 
$el_id=$_POST["el_id"];
$el_date=$_POST["el_date"];

$sql = "UPDATE employee_leaves SET el_date='".$el_date."' WHERE el_id = '".$el_id."' ";
$result = $conn->query($sql);
echo $result;

$conn->close();

?>

