<?php
session_start();
require '../../../../common/connection.php';

$el_id = $_POST['el_id'];

$sql = "UPDATE employee_leaves SET el_status=1 WHERE el_id = $el_id ";
$result = $conn->query($sql);

if($result){
	echo "Employee Leaves Deleted";
}
else{
	echo "Employee Leaves Not Deleted";
}

$conn->close();

?>

