$(document).ready(function(e){

  if (localStorage.getItem("el_edit_details") === null) {
    alert("Invalid Action");
    window.location="employeeleaves-list.html";
  }



  var json = localStorage.getItem("el_edit_details");
  var el_edit_details = JSON.parse(json);
  var el_id = el_edit_details.el_id;
  var em_first_name = el_edit_details.em_first_name;
  var em_last_name = el_edit_details.em_last_name;  
  var el_date = el_edit_details.el_date;
  var em_mobile = el_edit_details.em_mobile;
  var em_address = el_edit_details.em_address;
  
  

  // $("#id_lbl_storageId").html(el_id);
  $("#id_txt_el_em_first_name").val(em_first_name+" "+em_last_name+" "+em_mobile);
  // $('#id_num_el_capacity').val(el_capacity);
  $('#id_date_el_date').val(el_date);


    $("#id_btnUpdateData").click(function(e) {

    var el_em_id, el_date;

    // el_em_id = $("#id_txt_el_em_first_name").val();
    // el_em_id = el_em_id.split(' ')[0]; 
    el_date = $("#id_date_el_date").val();
    
      var nameRegex = /^[a-zA-Z ]{2,30}$/;
      var numberRegex = /^[0-9]{1,10}$/;
      var emailRegex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      var mobileNumberRegex = /^\d{10}$/;
        var nameNumberRegex = /[^A-Za-z0-9 ]+/;
    if($('#id_date_el_date').val() == undefined || $('#id_date_el_date').val() == "")
        {     
          $("#id_small_el_date").html("Please Select Date");
          $("#id_small_el_date").show().delay(4000).fadeOut();            
          $('#id_date_el_date').focus();
          return false;
        }  
    else
    {
      // sm_available = sm_available - el_milk;
      $.ajax({
            type: 'POST',
            url: '../php/employeeleaves-edit.php',
            data: {el_id : el_id, el_date : el_date}
       })
      .done(function(response){ 
      
            if(response == 1){

              localStorage.removeItem("el_edit_details");
              alert("Leaves Marked Updated..!");
              window.location="employeeleaves-list.html";

               }else{
            alert(response);

            
            }
       })
       .fail(function(response) {

          console.log("Oop's Something went wrong..!");
          alert(response);
       });
       return false;
    }
  });

    $("#id_back").click(function(e) {
      window.location="employeeleaves-list.html";
    });



});