$(document).ready(function(e){

  var dataSet,columns;

  localStorage.removeItem("el_edit_details");              

	$.ajax({
          type: 'POST',
          url: '../php/employeeleaves-list.php'
          
  	})
  .done(function(data){ 
    
    dataSet=JSON.parse(data);
    $('#id_list').DataTable( {
        data: dataSet,
        columns: [
            {"className": "dt-center", title: "SR NO" },
            {"className": "dt-center", title: "EmployeeLeaves Id" },
            {"className": "dt-center", title: "First Name" },
            {"className": "dt-center", title: "Last Name" },
            {"className": "dt-center", title: "Date" },
            {"className": "dt-center", title: "Mobile" },
            {"className": "dt-center", title: "Address" },
            {"className": "dt-center", title: "Created Date" },
            {"className": "dt-center", title: "Action" },
        ],
        // dom: 'Bfrtip',
        // buttons: [

        //         { extend: 'pdf', className: 'btn btn-primary glyphicon glyphicon-file' }
        //     // 'pdf'
        // ]
        // buttons: [
        //     {
        //         extend: 'pdf',
        //         customize: function ( win ) {
        //             $(win.document.body)
        //                 .css( 'font-size', '10pt' )
        //                 .prepend(
        //                     '<img src="http://datatables.net/media/images/logo-fade.png" style="position:absolute; top:0; left:0;" />'
        //                 );
 
        //             $(win.document.body).find( 'table' )
        //                 .addClass( 'compact' )
        //                 .css( 'font-size', 'inherit' );
        //         }
        //     }
        // ]
        // buttons: [
        //     'copy', 'csv', 'excel', 'pdf', 'print'
        // ]
    } );
  })
  .fail(function(data) {
    alert(data);
  }); 



 

  









  $("#id_list").on("click", ".fa-pencil-square-o", (function (ev){
    
    var el_id,em_first_name,em_last_name,el_date,em_mobile,em_address;
    el_id = $(this).parent().parent().children().children(".el_id").html();
    em_first_name = $(this).parent().parent().children().children(".em_first_name").html();
    em_last_name = $(this).parent().parent().children().children(".em_last_name").html();
    el_date = $(this).parent().parent().children().children(".el_date").html();
    em_mobile = $(this).parent().parent().children().children(".em_mobile").html();
    em_address = $(this).parent().parent().children().children(".em_address").html();
    
    var el_edit_details = { "el_id" : el_id, "em_first_name" : em_first_name, "em_last_name" : em_last_name, el_date : el_date, "em_mobile" : em_mobile, "em_address" : em_address};
    var myJSON = JSON.stringify(el_edit_details);    
    localStorage.setItem("el_edit_details", myJSON);

    if (localStorage.getItem("el_edit_details") != null) {
	  window.location="employeeleaves-edit.html";
	}
    }));



  $("#id_list").on("click", ".fa-trash-o", (function (ev){
    
    
    
    var el_id;
    el_id = $(this).parent().parent().children().children(".el_id").html();

    if (el_id != null || el_id !='' || el_id !=undefined) {
    	if (confirm("Are you sure want to delete?")) {

    
			    $.ajax({
			      type: 'POST',
			      url: '../php/employeeleaves-delete.php',
			      data: {el_id:el_id}
			    })
			    .done(function(data){
			    	alert(data); 
			    	location.reload();			      
			    })
			    .fail(function(data) {
			      alert(data);
			    });
		}
    }
    else{
    	alert("Invalid Action..!");
    }
    }));



});