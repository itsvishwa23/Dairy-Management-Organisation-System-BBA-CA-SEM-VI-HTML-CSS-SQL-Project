


$(document).ready(function(e){

	var milkrate,sm_available;
 
	 $('#id_txt_el_em_first_name').typeahead({
	  source: function(query, result)
	  {
	   $.ajax({
	    url:"../php/fetch.php",
	    method:"POST",
	    data:{query:query},
	    dataType:"json",
	    success:function(data)
	    {
	     result($.map(data, function(item){
	     	console.log(item[2]);
	      // alert(item);
	      return item[0]+" "+item[1]+" "+item[2]+" "+item[3]+" "+"("+item[4]+")";
	     }));
	    }
	   })
	  }, afterSelect: function (data) {
        //print the data to developer tool's console
        console.log(data);
        }
	 });



       
        // $.ajax({
        //       type: 'POST',
        //       url: '../php/get-storage.php',
        //       data: {}        
        // })
        // .done(function(response){
        //   $("#id_el_sm_id").html(response);
        // })
        // .fail(function(response) {
        //       console.log(response);
        // });  



        $.ajax({
              type: 'POST',
              url: '../php/get-snf.php',
              data: {}        
        })
        .done(function(response){
          $("#id_el_mrm_snf").html(response);

        })
        .fail(function(response) {
              console.log(response);
        });




        $("#id_el_mrm_snf").change(function(){
        	$.ajax({
              type: 'POST',
              url: '../php/get-milkrate-by-id.php',
              data: {mrm_id:$("#id_el_mrm_snf").val()}        
	        })
	        .done(function(response){
	          $("#id_lbl_el_mrm_rate").html(response);
	          milkrate = response;
	          calcAmount();
	        })
	        .fail(function(response) {
	              console.log(response);
	        });
		});


        

        $("#id_el_sm_id").change(function(){
        	$.ajax({
              type: 'POST',
              url: '../php/get-storage-by-id.php',
              data: {sm_id:$("#id_el_sm_id").val()}        
	        })
	        .done(function(response){
	          $("#id_lbl_el_storage_avialability").html(response+' Litre');
	          sm_available = response;
	          // calcAmount();
	        })
	        .fail(function(response) {
	              console.log(response);
	        });
		});


		$( "#el_date" ).keyup(function() {

	        $("#id_lbl_el_storage_avialability").html('');

			$.ajax({
              type: 'POST',
              url: '../php/get-storage-filter.php',
              data: {milk:$("#el_date").val()}        
	        })
	        .done(function(response){
	          $("#id_el_sm_id").html(response);
	          calcAmount();
	        })
	        .fail(function(response) {
	              console.log(response);
	        });  

		  // calcAmount();
		});

		function calcAmount(){

			console.log("keypress");

			var milk = $("#el_date").val();

	          $("#id_lbl_el_totalAmount").html(milk * milkrate);
		}

	localStorage.removeItem("sm_edit_details"); 
	$("#id_small_sm_name").hide(); 
	$("#id_small_sm_capacity").hide();                           

	$("#id_btnSaveData").click(function(e) {

		var el_em_id, el_date;

		el_em_id = $("#id_txt_el_em_first_name").val();
		el_em_id = el_em_id.split(' ')[0]; 
		el_date = $("#id_date_el_date").val();
		
	    var nameRegex = /^[a-zA-Z ]{2,30}$/;
	    var numberRegex = /^[0-9]{1,10}$/;
	    var emailRegex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	    var mobileNumberRegex = /^\d{10}$/;
        var nameNumberRegex = /[^A-Za-z0-9 ]+/;
	 	if($('#id_txt_el_em_first_name').val() == undefined || $('#id_txt_el_em_first_name').val() == "")
      	{	
      		$("#id_small_el_em_first_name").html("Please Search Employee Name");
      		$("#id_small_el_em_first_name").show().delay(4000).fadeOut();
      		$('#id_txt_el_em_first_name').focus();
      		return false;
      	} 
      	else if($('#id_date_el_date').val() == undefined || $('#id_date_el_date').val() == "")
      	{			
      		$("#id_small_el_date").html("Please Select Date");
      		$("#id_small_el_date").show().delay(4000).fadeOut();	      		
      		$('#id_date_el_date').focus();
      		return false;
      	}  
		else
		{ 
		  // sm_available = sm_available - el_milk;
		  $.ajax({
		        type: 'POST',
		        url: '../php/employeeleaves-add.php',
		        data: {el_em_id : el_em_id, el_date : el_date}
		   })
		  .done(function(response){ 
		  
		        if(response == 1){
		        alert("Leaves Marked..!");

				location.reload();
		   }else{
		        alert(response);

		        
		        }
		   })
		   .fail(function(response) {

		   		console.log("Oop's Something went wrong..!");
		   		alert(response);
		   });
		   return false;
		}
	});


});