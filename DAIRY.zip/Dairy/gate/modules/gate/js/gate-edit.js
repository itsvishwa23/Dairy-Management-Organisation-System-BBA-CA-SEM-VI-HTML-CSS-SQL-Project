$(document).ready(function(e){

  if (localStorage.getItem("gm_edit_details") === null) {
    alert("Invalid Action");
    window.location="gate-list.html";
  }



  var json = localStorage.getItem("gm_edit_details");
  var gm_edit_details = JSON.parse(json);
  var gm_id = gm_edit_details.gm_id;
  var gm_vehicle_no = gm_edit_details.gm_vehicle_no;
  var gm_description = gm_edit_details.gm_description;
  var gm_quantity = gm_edit_details.gm_quantity;
  var gm_ward_entry = gm_edit_details.gm_ward_entry;


  // $("#id_lbl_employeeId").html(em_id);
  $("#id_txt_gm_vehicle_no").val(gm_vehicle_no);
  $("#id_txt_gm_description").val(gm_description);
  $('#id_num_gm_quantity').val(gm_quantity);
  $('#id_select_gm_ward_entry').val(gm_ward_entry);

    $("#id_btnUpdateData").click(function(e) {


      var nameRegex = /^[a-zA-Z ]{2,30}$/;
      var numberRegex = /^[0-9]{1,10}$/;
      var emailRegex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      var mobileNumberRegex = /^\d{10}$/;

    
    var gm_vehicle_no,gm_description,gm_quantity,gm_ward_entry;
    gm_vehicle_no=$("#id_txt_gm_vehicle_no").val();
    gm_description=$("#id_txt_gm_description").val();
    gm_quantity=$("#id_num_gm_quantity").val();
    gm_ward_entry=$("#id_select_gm_ward_entry").val();



    if($('#id_txt_gm_vehicle_no').val() == undefined || $('#id_txt_gm_vehicle_no').val() == "")
        { 
          $("#id_small_gm_vehicle_no").html("Please Enter Vehicle No");
          $("#id_small_gm_vehicle_no").show().delay(4000).fadeOut();
          $('#id_txt_gm_vehicle_no').focus();
          return false;
        } 
    else if($('#id_txt_gm_description').val() == undefined || $('#id_txt_gm_description').val() == "")
        { 
          $("#id_small_gm_description").html("Please Enter Description");
          $("#id_small_gm_description").show().delay(4000).fadeOut();
          $('#id_txt_gm_description').focus();
          return false;
        } 
        else if($('#id_num_gm_quantity').val() == undefined || $('#id_num_gm_quantity').val() == "")
        {     
          $("#id_small_gm_quantity").html("Please Enter Quantity");
          $("#id_small_gm_quantity").show().delay(4000).fadeOut();            
          $('#id_num_gm_quantity').focus();
          return false;
        } 
        else if($('#id_select_gm_ward_entry').val() == undefined || $('#id_select_gm_ward_entry').val() == "")
        {     
          $("#id_small_gm_ward_entry").html("Please Select Ward");
          $("#id_small_gm_ward_entry").show().delay(4000).fadeOut();            
          $('#id_select_gm_ward_entry').focus();
          return false;
        }     
    else
    {
      var data = {gm_id : gm_id, gm_vehicle_no:gm_vehicle_no, gm_description : gm_description, gm_quantity : gm_quantity, gm_ward_entry:gm_ward_entry};        
      $.ajax({
            type: 'POST',
            url: '../php/gate-edit.php',
            data: data
       })
      .done(function(response){ 
      
            if(response>0){

              localStorage.removeItem("gm_edit_details");              
              alert("Vehicle Updated..!");
              window.location="gate-list.html";
              
            }
            else{
              alert("Vehicle not Updated -(:");
              
            
            }

       })
       .fail(function(response) {

          console.log("Oop's Something went wrong..!");
          alert(response);
       });
       return false;
    }
  });

    $("#id_back").click(function(e) {
      window.location="gate-list.html";
    });



});