$(document).ready(function(e){

	localStorage.removeItem("gm_edit_details"); 
	$("#id_small_gm_vehicle_no").hide(); 
	$("#id_small_gm_description").hide(); 
	$("#id_small_gm_quantity").hide(); 
	$("#id_small_gm_ward_entry").hide();                                 

	$("#id_btnSaveData").click(function(e) {

            


	    var nameRegex = /^[a-zA-Z ]{2,30}$/;
	    var numberRegex = /^[0-9]{1,10}$/;
	    var emailRegex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	    var mobileNumberRegex = /^\d{10}$/;

		
		var gm_vehicle_no,gm_description,gm_quantity,gm_ward_entry;
		gm_vehicle_no=$("#id_txt_gm_vehicle_no").val();
		gm_description=$("#id_txt_gm_description").val();
		gm_quantity=$("#id_num_gm_quantity").val();
		gm_ward_entry=$("#id_select_gm_ward_entry").val();
	 	if($('#id_txt_gm_vehicle_no').val() == undefined || $('#id_txt_gm_vehicle_no').val() == "")
      	{	
      		$("#id_small_gm_vehicle_no").html("Please Enter Vehicle Number");
      		$("#id_small_gm_vehicle_no").show().delay(4000).fadeOut();
      		$('#id_txt_gm_vehicle_no').focus();
      		return false;
      	} 
      	else if($('#id_txt_gm_description').val() == undefined || $('#id_txt_gm_description').val() == "")
      	{			
      		$("#id_small_gm_description").html("Please Enter Description");
      		$("#id_small_gm_description").show().delay(4000).fadeOut();	      		
      		$('#id_txt_gm_description').focus();
      		return false;
      	} 	 
      	else if($('#id_num_gm_quantity').val() == undefined || $('#id_num_gm_quantity').val() == "")
      	{			
      		$("#id_small_gm_quantity").html("Please Enter Quantity");
      		$("#id_small_gm_quantity").show().delay(4000).fadeOut();	      		
      		$('#id_num_gm_quantity').focus();
      		return false;
      	} 		
		else
		{
		  var data = {gm_vehicle_no: gm_vehicle_no, gm_description : gm_description, gm_quantity : gm_quantity,gm_ward_entry: gm_ward_entry};        
		  $.ajax({
		        type: 'POST',
		        url: '../php/gate-add.php',
		        data: data
		   })
		  .done(function(response){ 
		  
		        if(response == 1){
		        alert("Vehicle Added Successfully..!");
				location.reload();
		   }else{
		        alert("Vehicle Not Added -(:");
		        alert(response);
                    // alert(response);
		        
		        }

		   })
		   .fail(function(response) {

		   		console.log("Oop's Something went wrong..!");
		   		alert(response);
		   });
		   return false;
		}
	});


});