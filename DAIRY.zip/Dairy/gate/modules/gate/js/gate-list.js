$(document).ready(function(e){

  localStorage.removeItem("gm_edit_details");              

	$.ajax({
          type: 'POST',
          url: '../php/gate-list.php'
          
  	})
  .done(function(data){ 
    
    var dataSet=JSON.parse(data);
    // console.log(data);
    // alert(data);
    // var dataSet2 = [["Tiger Nixon","System Architect","Edinburgh"],
    //   ["Garrett Winters","Accountant","Tokyo"],
    //   ["Ashton Cox","Junior Technical Author","San Francisco"]];

    $('#id_list').DataTable( {
        data: dataSet,
        columns: [
            {"className": "dt-center", title: "SR NO" },
            {"className": "dt-center", title: "Vehicle" },
            {"className": "dt-center", title: "Description" },
            {"className": "dt-center", title: "Quantity" },
            {"className": "dt-center", title: "InWard/OutWard" },
            {"className": "dt-center", title: "Created At" },
            {"className": "dt-center", title: "Action" }
        ]
    } );
  })
  .fail(function(data) {
    alert(data);
  });  

  $("#id_list").on("click", ".fa-pencil-square-o", (function (ev){
    
    
    
    var gm_id,gm_vehicle_no,gm_description,gm_quantity,gm_ward_entry;
    gm_id = $(this).parent().parent().children().children(".gm_id").html();
    gm_vehicle_no = $(this).parent().parent().children().children(".gm_vehicle_no").html();
    gm_description = $(this).parent().parent().children().children(".gm_description").html();
    gm_quantity = $(this).parent().parent().children().children(".gm_quantity").html();
    gm_ward_entry = $(this).parent().parent().children().children(".gm_ward_entry").html();
    
    
    var gm_edit_details = { "gm_id" : gm_id, "gm_vehicle_no": gm_vehicle_no, "gm_description" : gm_description, "gm_quantity" : gm_quantity, "gm_ward_entry": gm_ward_entry};
    var myJSON = JSON.stringify(gm_edit_details);    
    localStorage.setItem("gm_edit_details", myJSON);

    if (localStorage.getItem("gm_edit_details") != null) {
	  window.location="gate-edit.html";
	}
    }));



  $("#id_list").on("click", ".fa-trash-o", (function (ev){
    
    
    
    var gm_id;
    gm_id = $(this).parent().parent().children().children(".gm_id").html();

    if (gm_id != null || gm_id !='' || gm_id !=undefined) {
    	if (confirm("Are you sure want to delete this Vehicle?")) {

    
			    $.ajax({
			      type: 'POST',
			      url: '../php/gate-delete.php',
			      data: {gm_id:gm_id}
			    })
			    .done(function(data){
			    	alert(data); 
			    	location.reload();			      
			    })
			    .fail(function(data) {
			      alert(data);
			    });
		}
    }
    else{
    	alert("Invalid Action..!");
    }
    }));



});