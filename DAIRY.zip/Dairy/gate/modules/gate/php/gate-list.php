<?php
session_start();
require '../../../../common/connection.php';

$i=0;

$sql="select * from gate_master where gm_status = 0";
$result = $conn->query($sql);

$list = array();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		array_push($list,array(++$i."<span class='gm_id' style='display:none;'>".$row["gm_id"]."</span>",$row["gm_vehicle_no"]."<span class='gm_vehicle_no' style='display:none;'>".$row["gm_vehicle_no"]."</span>",$row["gm_description"]."<span class='gm_description' style='display:none;'>".$row["gm_description"]."</span>",$row["gm_quantity"]."<span class='gm_quantity' style='display:none;'>".$row["gm_quantity"]."</span>",$row["gm_ward_entry"]."<span class='gm_ward_entry' style='display:none;'>".$row["gm_ward_entry"]."</span>",$row["gm_created_at"]."<span class='gm_created_at' style='display:none;'>".$row["gm_created_at"]."</span>","<i style='cursor:pointer;' class='fa fa-pencil-square-o' ></i> &nbsp; <i style='cursor:pointer;' class='fa fa-trash-o'></i>"));
    }
} else {
    echo "0 results";
}


$myJSON = json_encode($list);
echo $myJSON;
$conn->close();
?>