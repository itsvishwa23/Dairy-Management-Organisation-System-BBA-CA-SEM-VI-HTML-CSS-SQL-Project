<?php
session_start();
require '../../../../common/connection.php';
$sqlchk = "SELECT rmm_id FROM raw_material_master ORDER BY rmm_id DESC LIMIT 1";
$result = $conn->query($sqlchk);

			if ($result->num_rows == 1) {
				$row = $result->fetch_assoc();
				echo $row["rmmm_id"];
			}
			else{
				echo "0";
			}
$conn->close();
?>