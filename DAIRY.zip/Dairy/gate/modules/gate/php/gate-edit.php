<?php
session_start();
require '../../../../common/connection.php';

$gm_id=$_POST["gm_id"];
$gm_vehicle_no=$_POST["gm_vehicle_no"];
$gm_description=$_POST["gm_description"];
$gm_quantity=$_POST["gm_quantity"];
$gm_ward_entry=$_POST["gm_ward_entry"];


$sql = "UPDATE gate_master SET gm_vehicle_no='".$gm_vehicle_no."', gm_quantity='".$gm_quantity."', gm_description='".$gm_description."',gm_ward_entry='".$gm_ward_entry."' WHERE gm_id = '".$gm_id."' ";
$result = $conn->query($sql);
echo $result;

$conn->close();

?>

