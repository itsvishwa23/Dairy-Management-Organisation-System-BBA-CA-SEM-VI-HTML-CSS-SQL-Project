<?php
session_start();
require '../../../../common/connection.php';


$gm_vehicle_no=$_POST["gm_vehicle_no"];
$gm_description=$_POST["gm_description"];

$gm_quantity=$_POST["gm_quantity"];
$gm_ward_entry=$_POST["gm_ward_entry"];

// $sqlchk = "SELECT em_mobile from employee_master where em_mobile='" .$em_mobile. "'";
// $result = $conn->query($sqlchk);

			// if ($result->num_rows > 0) {
				// echo "This is Existing Employee..!";
			// }
			// else{
					$sql = "INSERT gate_master(gm_vehicle_no,gm_description,gm_quantity,gm_ward_entry) VALUES ('".$gm_vehicle_no."','".$gm_description."','".$gm_quantity."','".$gm_ward_entry."')";
					$insert = $conn->query($sql);
					echo $insert;
					// if($insert)
					// 	echo "ok";
					// else
					// 	echo "not ok";
			// }
$conn->close();
?>