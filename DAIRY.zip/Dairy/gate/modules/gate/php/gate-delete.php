<?php
session_start();
require '../../../../common/connection.php';

$gm_id = $_POST['gm_id'];

$sql = "UPDATE gate_master SET gm_status=1 WHERE gm_id = $gm_id ";
$result = $conn->query($sql);

if($result){
	echo "Vehicle Deleted";
}
else{
	echo "Vehicle Not Deleted";
}

$conn->close();

?>

