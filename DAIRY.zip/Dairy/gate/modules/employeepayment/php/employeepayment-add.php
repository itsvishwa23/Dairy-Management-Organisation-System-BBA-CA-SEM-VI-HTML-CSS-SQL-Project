<?php
session_start();
require '../../../../common/connection.php';
		        
$ep_em_id=$_POST["ep_em_id"];
$ep_present_days=$_POST["ep_present_days"];
$ep_daily_wages=$_POST["ep_daily_wages"];
$startDate=$_POST["startDate"];
$endDate=$_POST["endDate"];

$sql = "INSERT employee_payment(ep_em_id,ep_present_days,ep_daily_wages) VALUES ('".$ep_em_id."','".$ep_present_days."','".$ep_daily_wages."')";

$insert = $conn->query($sql);
if($insert == 1){
	$sql = "UPDATE employee_leaves SET el_payment_status = 'paid' WHERE el_date BETWEEN '".$startDate."' AND '".$endDate."'";
	$result = $conn->query($sql);
	echo $result;
}			
$conn->close();
?>