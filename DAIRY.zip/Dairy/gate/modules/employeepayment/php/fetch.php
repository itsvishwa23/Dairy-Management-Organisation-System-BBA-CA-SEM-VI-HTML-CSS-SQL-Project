<?php

session_start();
require '../../../../common/connection.php';
$request = mysqli_real_escape_string($conn, $_POST["query"]);
$query = "
 SELECT * FROM employee_master WHERE em_first_name LIKE '%".$request."%' and em_status = 0 or em_last_name LIKE '%".$request."%' and em_status = 0 ";


// $query = "SELECT * FROM farmer_master WHERE fm_first_name LIKE '%'.$request.'%' ";



$result = mysqli_query($conn, $query);

$data = array();

if(mysqli_num_rows($result) > 0)
{
 while($row = mysqli_fetch_assoc($result))
 {
 	array_push($data,array($row["em_id"],$row["em_first_name"],$row["em_last_name"],$row["em_address"],$row["em_mobile"]));
  // $data[] = $row["fm_first_name"]."	".$row["fm_last_name"]."	".$row["fm_address"];
 }
 echo json_encode($data);
}

?>
