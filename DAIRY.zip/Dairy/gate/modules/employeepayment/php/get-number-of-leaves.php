<?php
session_start();

$el_em_id=$_POST["el_em_id"];
$startDate=$_POST["startDate"];
$endDate=$_POST["endDate"];

require '../../../../common/connection.php';
// $sqlchk = "SELECT mrm_rate FROM milk_rate_master where el_em_id = $el_em_id";

$sqlchk = "SELECT * FROM employee_leaves WHERE el_em_id = '".$el_em_id."' AND el_payment_status = 'paid' AND el_status = 0 AND el_date BETWEEN '".$startDate."' AND '".$endDate."' ";

$result = $conn->query($sqlchk);

			if ($result->num_rows > 0) {
				// $row = $result->fetch_assoc();
				// echo $row["NumberOfLeaves"];
				echo "This Employee Payment has been already Paid";
			}
			else{

				$sqlchk = "SELECT COUNT(el_id) AS NumberOfLeaves FROM employee_leaves WHERE el_em_id = '".$el_em_id."' AND el_payment_status = 'unpaid' AND el_status = 0 AND el_date BETWEEN '".$startDate."' AND '".$endDate."' ";

				$result = $conn->query($sqlchk);

				if ($result->num_rows == 1) {
					$row = $result->fetch_assoc();
					echo $row["NumberOfLeaves"];
				}
				
			}

// $sqlchk = "SELECT COUNT(el_id) AS NumberOfLeaves FROM employee_leaves WHERE el_em_id = 2 AND el_payment_status = 'unpaid' AND el_status = 0 AND el_date BETWEEN '2020-01-20' AND '2020-01-30'";


$conn->close();
?>