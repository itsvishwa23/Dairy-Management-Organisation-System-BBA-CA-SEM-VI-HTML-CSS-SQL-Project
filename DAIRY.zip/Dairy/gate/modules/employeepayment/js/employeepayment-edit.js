$(document).ready(function(e){

  if (localStorage.getItem("ep_edit_details") === null) {
    alert("Invalid Action");
    window.location="employeepayment-list.html";
  }



  var json = localStorage.getItem("ep_edit_details");
  var ep_edit_details = JSON.parse(json);
  var ep_id = ep_edit_details.ep_id;
  var em_first_name = ep_edit_details.em_first_name;
  var em_last_name = ep_edit_details.em_last_name;  
  var em_address = ep_edit_details.em_address;
  var em_mobile = ep_edit_details.em_mobile;
  var ep_present_days = ep_edit_details.ep_present_days;
  var ep_daily_wages = ep_edit_details.ep_daily_wages;
  
  

  // $("#id_lbl_employeepaymentId").html(ep_id);
  $("#id_txt_ep_em_first_name").val(em_first_name+" "+em_last_name+" "+em_address+" "+em_mobile);
  $("#id_lbl_ep_present_days").html(ep_present_days);
  $('#id_txt_ep_daily_wages').val(ep_daily_wages);
  $("#id_lbl_ep_totalAmount").html(ep_present_days * ep_daily_wages);



   $("#id_date_ep_start_date").change(function(){

          calcAmount();
    });

    $("#id_date_ep_end_date").change(function(){

      calcAmount();
    });


    $( "#id_txt_ep_daily_wages" ).keyup(function() {

      calcTotalAmount();
    });

    function calcAmount(){



      date1 = new Date($('#id_date_ep_start_date').val());
      date2 = new Date($('#id_date_ep_end_date').val());

      var Difference_In_Time = date2.getTime() - date1.getTime(); 
      Difference_In_Time = Difference_In_Time / (1000 * 3600 * 24);
      Difference_In_Time = Difference_In_Time + 1;
        el_em_id = $("#id_txt_ep_em_first_name").val();
      el_em_id = el_em_id.split(' ')[0]; 

      var startDate = $("#id_date_ep_start_date").val(); 
      var endDate= $("#id_date_ep_end_date").val();

        $.ajax({
              type: 'POST',
              url: '../php/get-number-of-leaves.php',
              data: {el_em_id : el_em_id, startDate : startDate, endDate : endDate}        
          })
          .done(function(response){
            if(response == 0){
              presentDays = "This Employee Payment has been already Paid";
              $("#id_lbl_ep_present_days").html(presentDays);           
            }
            else{
            presentDays = parseInt(Difference_In_Time)  - parseInt(response);
              $("#id_lbl_ep_present_days").html(presentDays);

            }
          })
          .fail(function(response) {
                console.log(response);
          });
    }

    function calcTotalAmount(){
      var dailyWages = $("#id_txt_ep_daily_wages").val();
      var totalAmount = presentDays * dailyWages;                 
          $("#id_lbl_ep_totalAmount").html(totalAmount);

    }


    $("#id_btnUpdateData").click(function(e) {


      var nameRegex = /^[a-zA-Z ]{2,30}$/;
      var numberRegex = /^[0-9]{1,10}$/;
      var emailRegex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      var mobileNumberRegex = /^\d{10}$/;
      var nameNumberRegex = /[^A-Za-z0-9 .]+/;

    
    var ep_name,ep_capacity,ep_milk_available;
    ep_name=$("#id_txt_ep_name").val();
    ep_capacity=$("#id_num_ep_capacity").val();    
    ep_milk_available=$("#id_num_sm_milk_available").val();
    if($('#id_txt_sm_name').val() == undefined || $('#id_txt_sm_name').val() == "")
        { 
          $("#id_small_sm_name").html("Please Enter employeepayment Name");
          $("#id_small_sm_name").show().delay(4000).fadeOut();
          $('#id_txt_sm_name').focus();
          return false;
        } 
        else if($('#id_num_sm_capacity').val() == undefined || $('#id_num_sm_capacity').val() == "")
        {     
          $("#id_small_sm_capacity").html("Please Enter employeepayment Capacity");
          $("#id_small_sm_capacity").show().delay(4000).fadeOut();            
          $('#id_num_sm_capacity').focus();
          return false;
        } 
        else if($('#id_num_sm_milk_available').val() == undefined || $('#id_num_sm_milk_available').val() == "")
        {     
          $("#id_small_sm_milk_available").html("Please Enter Number or 0");
          $("#id_small_sm_milk_available").show().delay(4000).fadeOut();            
          $('#id_num_sm_milk_available').focus();
          return false;
        }           
        else if(nameNumberRegex.test($('#id_txt_sm_name').val())){              
          $("#id_small_sm_name").html("Please Enter valid employeepayment Name");
          $("#id_small_sm_name").show().delay(4000).fadeOut();
          $('#id_txt_sm_name').focus();
          return false;
        }           
        else if(parseFloat(sm_milk_available) > parseFloat(sm_milk_available_old)){              
          $("#id_small_sm_milk_available").html("Increasing milk Prohibited");
          $("#id_small_sm_milk_available").show().delay(4000).fadeOut();
          $('#id_num_sm_milk_available').focus();
          return false;
        }           
        else if(parseFloat(sm_milk_available) < 0){              
          $("#id_small_sm_milk_available").html("Invalid Number");
          $("#id_small_sm_milk_available").show().delay(4000).fadeOut();
          $('#id_num_sm_milk_available').focus();
          return false;
        } 
    else
    {
      if(parseFloat(sm_milk_available) === parseFloat(sm_milk_available_old))
        sm_available = parseFloat(sm_available)  + parseFloat(0);
      else{
        var sm_milk_available_temp = parseFloat(sm_milk_available_old) - parseFloat(sm_milk_available);
        sm_available = parseFloat(sm_available) + parseFloat(sm_milk_available_temp);
        sm_milk_available = parseFloat(sm_milk_available_old) - parseFloat(sm_milk_available_temp);
      }
      
      
      
      $.ajax({
            type: 'POST',
            url: '../php/employeepayment-edit.php',
            data: {sm_id : sm_id, sm_name : sm_name, sm_capacity : sm_capacity, sm_available : sm_available, sm_milk_available : sm_milk_available}
       })
      .done(function(response){ 
      
            if(response == 1){

              localStorage.removeItem("sm_edit_details");              
              alert("employeepayment Updated..!");
              window.location="employeepayment-list.html";
              
            }
            else{
              alert("employeepayment not Updated -(:");
            
            }

       })
       .fail(function(response) {

          console.log("Oop's Something went wrong..!");
          alert(response);
       });
       return false;
    }
  });

    $("#id_back").click(function(e) {
      window.location="employeepayment-list.html";
    });



});