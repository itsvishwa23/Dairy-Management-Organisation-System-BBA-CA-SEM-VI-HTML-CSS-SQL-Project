$(document).ready(function(e){

	localStorage.removeItem("rmm_edit_details"); 
	$("#id_small_rmm_description").hide(); 
	$("#id_small_rmm_quantity").hide();                         

	$("#id_btnSaveData").click(function(e) {

            


	    var nameRegex = /^[a-zA-Z ]{2,30}$/;
	    var numberRegex = /^[0-9]{1,10}$/;
	    var emailRegex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	    var mobileNumberRegex = /^\d{10}$/;

		
		var rmm_description,rmm_quantity;
		rmm_description=$("#id_txt_rmm_description").val();
		rmm_quantity=$("#id_num_rmm_quantity").val();
	 	if($('#id_txt_rmm_description').val() == undefined || $('#id_txt_rmm_description').val() == "")
      	{	
      		$("#id_small_rmm_description").html("Please Enter Description");
      		$("#id_small_rmm_description").show().delay(4000).fadeOut();
      		$('#id_txt_rmm_description').focus();
      		return false;
      	} 
      	else if($('#id_num_rmm_quantity').val() == undefined || $('#id_num_rmm_quantity').val() == "")
      	{			
      		$("#id_small_em_lastName").html("Please Enter Last Name");
      		$("#id_small_em_lastName").show().delay(4000).fadeOut();	      		
      		$('#id_num_rmm_quantity').focus();
      		return false;
      	} 		
		else
		{
		  var data = {rmm_description : rmm_description, rmm_quantity : rmm_quantity};        
		  $.ajax({
		        type: 'POST',
		        url: '../php/rawmaterial-add.php',
		        data: data
		   })
		  .done(function(response){ 
		  
		        if(response == 1){
		        alert("Material Added Successfully..!");
				location.reload();
		   }else{
		        alert("Material Not Added -(:");
                    // alert(response);
		        
		        }

		   })
		   .fail(function(response) {

		   		console.log("Oop's Something went wrong..!");
		   		alert(response);
		   });
		   return false;
		}
	});


});