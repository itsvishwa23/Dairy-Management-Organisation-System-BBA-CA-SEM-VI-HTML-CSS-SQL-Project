$(document).ready(function(e){

  localStorage.removeItem("rmm_edit_details");              

	$.ajax({
          type: 'POST',
          url: '../php/rawmaterial-list.php'
          
  	})
  .done(function(data){ 
    
    var dataSet=JSON.parse(data);
    // console.log(data);
    // alert(data);
    // var dataSet2 = [["Tiger Nixon","System Architect","Edinburgh"],
    //   ["Garrett Winters","Accountant","Tokyo"],
    //   ["Ashton Cox","Junior Technical Author","San Francisco"]];

    $('#id_list').DataTable( {
        data: dataSet,
        columns: [
            {"className": "dt-center", title: "SR NO" },
            {"className": "dt-center", title: "Description" },
            {"className": "dt-center", title: "Quantity" },
            {"className": "dt-center", title: "Created At" },
            {"className": "dt-center", title: "Action" }
        ]
    } );
  })
  .fail(function(data) {
    alert(data);
  });  

  $("#id_list").on("click", ".fa-pencil-square-o", (function (ev){
    
    
    
    var rmm_id,rmm_description,rmm_quantity;
    rmm_id = $(this).parent().parent().children().children(".rmm_id").html();
    rmm_description = $(this).parent().parent().children().children(".rmm_description").html();
    rmm_quantity = $(this).parent().parent().children().children(".rmm_quantity").html();
    
    
    var rmm_edit_details = { "rmm_id" : rmm_id, "rmm_description" : rmm_description, "rmm_quantity" : rmm_quantity};
    var myJSON = JSON.stringify(rmm_edit_details);    
    localStorage.setItem("rmm_edit_details", myJSON);

    if (localStorage.getItem("rmm_edit_details") != null) {
	  window.location="rawmaterial-edit.html";
	}
    }));



  $("#id_list").on("click", ".fa-trash-o", (function (ev){
    
    
    
    var rmm_id;
    rmm_id = $(this).parent().parent().children().children(".rmm_id").html();

    if (rmm_id != null || rmm_id !='' || rmm_id !=undefined) {
    	if (confirm("Are you sure want to delete this Material?")) {

    
			    $.ajax({
			      type: 'POST',
			      url: '../php/rawmaterial-delete.php',
			      data: {rmm_id:rmm_id}
			    })
			    .done(function(data){
			    	alert(data); 
			    	location.reload();			      
			    })
			    .fail(function(data) {
			      alert(data);
			    });
		}
    }
    else{
    	alert("Invalid Action..!");
    }
    }));



});