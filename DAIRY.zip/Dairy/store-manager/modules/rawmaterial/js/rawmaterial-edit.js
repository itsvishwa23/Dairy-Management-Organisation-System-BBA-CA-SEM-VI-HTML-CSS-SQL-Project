$(document).ready(function(e){

  if (localStorage.getItem("rmm_edit_details") === null) {
    alert("Invalid Action");
    window.location="rawmaterial-list.html";
  }



  var json = localStorage.getItem("rmm_edit_details");
  var rmm_edit_details = JSON.parse(json);
  var rmm_id = rmm_edit_details.rmm_id;
  var rmm_description = rmm_edit_details.rmm_description;
  var rmm_quantity = rmm_edit_details.rmm_quantity;


  // $("#id_lbl_employeeId").html(em_id);
  $("#id_txt_rmm_description").val(rmm_description);
  $('#id_num_rmm_quantity').val(rmm_quantity);

    $("#id_btnUpdateData").click(function(e) {


      var nameRegex = /^[a-zA-Z ]{2,30}$/;
      var numberRegex = /^[0-9]{1,10}$/;
      var emailRegex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      var mobileNumberRegex = /^\d{10}$/;

    
    var rmm_description,rmm_quantity;
    rmm_description=$("#id_txt_rmm_description").val();
    rmm_quantity=$("#id_num_rmm_quantity").val();

    if($('#id_txt_rmm_description').val() == undefined || $('#id_txt_rmm_description').val() == "")
        { 
          $("#id_small_rmm_description").html("Please Enter First Name");
          $("#id_small_rmm_description").show().delay(4000).fadeOut();
          $('#id_txt_rmm_description').focus();
          return false;
        } 
        else if($('#id_num_rmm_quantity').val() == undefined || $('#id_num_rmm_quantity').val() == "")
        {     
          $("#id_small_rmm_quantity").html("Please Enter Last Name");
          $("#id_small_rmm_quantity").show().delay(4000).fadeOut();            
          $('#id_num_rmm_quantity').focus();
          return false;
        }     
    else
    {
      var data = {rmm_id : rmm_id, rmm_description : rmm_description, rmm_quantity : rmm_quantity};        
      $.ajax({
            type: 'POST',
            url: '../php/rawmaterial-edit.php',
            data: data
       })
      .done(function(response){ 
      
            if(response>0){

              localStorage.removeItem("rmm_edit_details");              
              alert("Material Updated..!");
              window.location="rawmaterial-list.html";
              
            }
            else{
              alert("Material not Updated -(:");
            
            }

       })
       .fail(function(response) {

          console.log("Oop's Something went wrong..!");
          alert(response);
       });
       return false;
    }
  });

    $("#id_back").click(function(e) {
      window.location="rawmaterial-list.html";
    });



});