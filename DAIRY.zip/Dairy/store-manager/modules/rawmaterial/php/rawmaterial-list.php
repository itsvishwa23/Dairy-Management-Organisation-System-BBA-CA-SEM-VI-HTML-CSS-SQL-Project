<?php
session_start();
require '../../../../common/connection.php';

$i=0;

// $sqlCount="SELECT count(*) as total from employee_master";
// $result = $conn->query($sqlCount);
// $data=$result->fetch_assoc();
// $count=$data['total'];

$sql="select * from raw_material_master where rmm_status = 0";
$result = $conn->query($sql);

$list = array();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		array_push($list,array(++$i."<span class='rmm_id' style='display:none;'>".$row["rmm_id"]."</span>",$row["rmm_description"]."<span class='rmm_description' style='display:none;'>".$row["rmm_description"]."</span>",$row["rmm_quantity"]."<span class='rmm_quantity' style='display:none;'>".$row["rmm_quantity"]."</span>",$row["rmm_created_at"]."<span class='rmm_created_at' style='display:none;'>".$row["rmm_created_at"]."</span>","<i style='cursor:pointer;' class='fa fa-pencil-square-o' ></i> &nbsp; <i style='cursor:pointer;' class='fa fa-trash-o'></i>"));
    }
} else {
    echo "0 results";
}


$myJSON = json_encode($list);
echo $myJSON;
$conn->close();
?>