<?php
session_start();
require '../../../../common/connection.php';


$rmm_description=$_POST["rmm_description"];
$rmm_quantity=$_POST["rmm_quantity"];

// $sqlchk = "SELECT em_mobile from employee_master where em_mobile='" .$em_mobile. "'";
// $result = $conn->query($sqlchk);

			// if ($result->num_rows > 0) {
				// echo "This is Existing Employee..!";
			// }
			// else{
					$sql = "INSERT raw_material_master(rmm_description,rmm_quantity) VALUES ('".$rmm_description."','".$rmm_quantity."')";
					$insert = $conn->query($sql);
					echo $insert;
					// if($insert)
					// 	echo "ok";
					// else
					// 	echo "not ok";
			// }
$conn->close();
?>