<?php
session_start();
require '../../../../common/connection.php';

$rmm_id = $_POST['rmm_id'];

$sql = "UPDATE raw_material_master SET rmm_status=1 WHERE rmm_id = $rmm_id ";
$result = $conn->query($sql);

if($result){
	echo "Material Deleted";
}
else{
	echo "Material Not Deleted";
}

$conn->close();

?>

