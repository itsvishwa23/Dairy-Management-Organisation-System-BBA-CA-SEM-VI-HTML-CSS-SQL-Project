<?php
session_start();
require '../../../../common/connection.php';

$rmm_id=$_POST["rmm_id"];
$rmm_description=$_POST["rmm_description"];
$rmm_quantity=$_POST["rmm_quantity"];


$sql = "UPDATE raw_material_master SET rmm_description='".$rmm_description."',rmm_quantity='".$rmm_quantity."' WHERE rmm_id = '".$rmm_id."' ";
$result = $conn->query($sql);
echo $result;

$conn->close();

?>

