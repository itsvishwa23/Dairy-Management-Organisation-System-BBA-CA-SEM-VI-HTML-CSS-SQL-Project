<?php
session_start();
// echo $_SESSION["username"];
session_destroy();
$_SESSION["pm_email"] = '';
$_SESSION["role"] = '';
echo "login.html";


?>