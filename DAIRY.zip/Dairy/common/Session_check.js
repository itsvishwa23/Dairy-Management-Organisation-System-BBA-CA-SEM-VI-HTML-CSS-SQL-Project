$(document).ready(function(e){
  $.ajax({
        type: 'POST',
        url: '../common/Session_check.php',
        data: {}        
      })
  .done(function(response){
    if(response=="login.html"){
      window.location = '../'+response;
    }
    else{
      $("#id_username").html(response);
    }
    
    
      })
      .fail(function(response) {
        console.log(response);
      });
      
      return false;


});


