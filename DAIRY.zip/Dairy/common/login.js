$(document).ready(function(e){

	$("#id_btn_signIn").click(function(e) {

		
	var email,password,role;
	email=$("#id_email").val();
	password=$("#id_password").val();
	role=$("#id_role").val();

	if(email==""){
	  alert('User Name should not be empty')
	  $('#id_email').focus();
	}
	else if(password==""){
	  alert('password should not be empty');
	  alert(role);
	  $('#id_password').focus();
	}
	else if(role==null){
	  alert('Please select Role');
	  $('#id_role').focus();
	}
	else
	{
	  $.ajax({
	        type: 'POST',
	        url: 'common/login.php',
	        data: {email : email, password : password, role : role}        
	      })
	  .done(function(response){ 
	  
	        if(response == "procurement"){        
	       
				// window.location="procurement/index.html";
				window.location="procurement/modules/collectmilk/html/collectmilk-add.html";
	        }
	        else if(response == "farmer"){        
	       
				// window.location="farmer/index.html";
				window.location="farmer/modules/collectmilk/html/collectmilk-list.html";

	        }
	        else if(response == "hr"){        
	       
				// window.location="farmer/index.html";
				window.location="hr/modules/employee/html/employee-add.html";

	        }
	        else if(response == "storeManager"){        
	       
				// window.location="farmer/index.html";
				window.location="store-manager/modules/rawmaterial/html/rawmaterial-add.html";

	        }
	        else if(response == "gate"){        
	       
				// window.location="farmer/index.html";
				window.location="gate/modules/gate/html/gate-add.html";

	        }	        
	        else if(response == "distributor"){        
	       
				// window.location="farmer/index.html";
				window.location="distributor/modules/product/html/product-add.html";

	        }
	        else{
	        	alert(response);
	        }

	      })
	      .fail(function(response) {
	      	alert("Oop's Something went wrong");
	//              Lobibox.alert('error',
	// {
	// msg: response
	// });
	      });
	      
	      return false;
	}



	});


});