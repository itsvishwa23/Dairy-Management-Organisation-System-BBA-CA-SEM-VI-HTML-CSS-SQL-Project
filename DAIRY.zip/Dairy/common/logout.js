$(document).ready(function(e){

$("#id_logout").click(function(e) {
  // console.log("id_logout clicked");
  $.ajax({
        type: 'POST',
        url: '../common/Session_destroy.php',
        data: {}        
      })
  .done(function(response){
    window.location = '../'+response;
    console.log(response);
      })
      .fail(function(response) {
        console.log(response);
      });
      
      return false;
});


});


