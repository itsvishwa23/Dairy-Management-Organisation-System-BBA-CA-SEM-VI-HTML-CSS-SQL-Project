<?php
session_start();
require 'connection.php';


$email=$_POST["email"];
$pass=$_POST["password"];
$role=$_POST["role"];


if($role == "Procurement"){




	$sql = "SELECT pm_id, pm_email, pm_password FROM procurement_master where pm_email='" . $email . "' AND pm_password='" .$pass . "'";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {

	    // while($row = $result->fetch_assoc()) {

			// $_SESSION["username"] = $email;
			$_SESSION["pm_email"] = $email;
			// $_SESSION["pm_id"] = $row["pm_id"];
			$_SESSION["role"] = $role;
			echo "procurement";
		// }
		
	}
	else
	{
		echo "Username and password did not matched";
	}

}
else if($role == "Farmer"){

	$sql = "SELECT fm_id, fm_email, fm_password FROM farmer_master where fm_email='" . $email . "' AND fm_password='" .base64_encode($pass) . "'";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
			$_SESSION["pm_email"] = $email;
			
			$_SESSION["role"] = $role;
			echo "farmer";
	}
	else
	{
		echo "Username and password did not matched";
	}

}

else if($role == "hr"){
	$sql = "SELECT hrm_id, hrm_email, hrm_password FROM hr_master where hrm_email='" . $email . "' AND hrm_password='" .$pass . "'";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
			$_SESSION["pm_email"] = $email;
			$_SESSION["role"] = $role;
			echo $role;
	}
	else
	{
		echo "Username and password did not matched";
	}
}

else if($role == "storeManager"){
	$sql = "SELECT sms_id, sms_email, sms_password FROM store_manager_master where sms_email='" . $email . "' AND sms_password='" .$pass . "'";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
			$_SESSION["pm_email"] = $email;
			$_SESSION["role"] = $role;
			echo $role;
	}
	else
	{
		echo "Username and password did not matched";
	}
}

else if($role == "gate"){
	$sql = "SELECT gk_id, gk_email, gk_password FROM gate_keeper_master where gk_email='" . $email . "' AND gk_password='" .$pass . "'";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
			$_SESSION["pm_email"] = $email;
			$_SESSION["role"] = $role;
			echo $role;
	}
	else
	{
		echo "Username and password did not matched";
	}
}


else if($role == "distributor"){
	$sql = "SELECT dm_id, dm_email, dm_password FROM distributor_master where dm_email='" . $email . "' AND dm_password='" .$pass . "'";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
			$_SESSION["pm_email"] = $email;
			$_SESSION["role"] = $role;
			echo $role;
	}
	else
	{
		echo "Username and password did not matched";
	}
}	
$conn->close();
?>