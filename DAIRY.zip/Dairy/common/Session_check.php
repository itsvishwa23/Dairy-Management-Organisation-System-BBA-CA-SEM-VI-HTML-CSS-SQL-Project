<?php
session_start();
// require 'connection.php';

if(!isset($_SESSION["pm_email"])){
	echo "login.html";
	
 }
 else{
 	echo $_SESSION["pm_email"];
 }
// 	else {
	
// 	$sql = "SELECT pm_first_name, pm_last_name FROM procurement_master where pm_email='" . $_SESSION["pm_email"] . "'";
// 	$result = $conn->query($sql);

// 	if ($result->num_rows > 0) {
// 		 while($row = $result->fetch_assoc()) {
// 			echo $row["pm_first_name"] ." ". $row["pm_last_name"];
// 		 }
// }
// else
// {
// 	echo "Username and password did not matched";
// }
// }
// $conn->close();
?>