$(document).ready(function(e){

  localStorage.removeItem("prm_edit_details");              

	$.ajax({
          type: 'POST',
          url: '../php/product-list.php'
          
  	})
  .done(function(data){ 
    // $("#id_list").html(data);
    // $("#example").html(data);
    
    var dataSet=JSON.parse(data);
    console.log(JSON.parse(data));

    $('#id_list').DataTable( {
        data: dataSet,
        columns: [
            {"className": "dt-center", title: "SR NO" },
            {"className": "dt-center", title: "Product Name" },
            {"className": "dt-center", title: "Product RATE" },
            {"className": "dt-center", title: "Created Date" },
            {"className": "dt-center", title: "Action" }
        ]
    } );

    // alert(data);
  })
  .fail(function(data) {
    alert(data);
  });  

  $("#id_list").on("click", ".fa-pencil-square-o", (function (ev){
    
    
    var prm_id,prm_name,prm_rate;
    prm_id = $(this).parent().parent().children().children(".prm_id").html();
    prm_name = $(this).parent().parent().children().children(".prm_name").html();
    prm_rate = $(this).parent().parent().children().children(".prm_rate").html();

    
    
    var prm_edit_details = {"prm_id":prm_id,"prm_name":prm_name,"prm_rate":prm_rate};
    var myJSON = JSON.stringify(prm_edit_details);    
    localStorage.setItem("prm_edit_details", myJSON);

    if (localStorage.getItem("prm_edit_details") != null) {
	  window.location="product-edit.html";
	}
    }));



  $("#id_list").on("click", ".fa-trash-o", (function (ev){
    
    
    
    var prm_id;
    prm_id = $(this).parent().parent().children().children(".prm_id").html();

    if (prm_id != null || prm_id !='' || prm_id !=undefined) {
    	if (confirm("Are you sure want to delete this Product?")) {

    
			    $.ajax({
			      type: 'POST',
			      url: '../php/product-delete.php',
			      data: {prm_id:prm_id}
			    })
			    .done(function(data){
			    	alert(data); 
            console.log(data);
			    	location.reload();			      
			    })
			    .fail(function(data) {
			      alert(data);
			    });
		}
    }
    else{
    	alert("Invalid Action..!");
    }
    }));



});