$(document).ready(function(e){

	localStorage.removeItem("prm_edit_details");              

	$("#id_saveData").click(function(e) {

		
		var prm_name,prm_rate;
		prm_name=$("#id_prm_name").val();
		prm_rate=$("#id_prm_rate").val();
		

		if(prm_name==null || prm_name=='' || prm_name==undefined){
		  alert('Please Select Product Name');
		  $('#id_prm_name').focus();
		}
		else if(prm_rate=="" || prm_rate==undefined || prm_rate==null){
		  alert('Please Enter Rate');
		  
		  $('#id_prm_rate').focus();
		}		
		else
		{
		  $.ajax({
		        type: 'POST',
		        url: '../php/product-add.php',
		        data: {prm_name : prm_name, prm_rate : prm_rate}        
		   })
		  .done(function(response){ 

		  		// alert(response);
		  
		        if(response == "ok"){
		        alert("Product Added Successfully..!");
				location.reload();
		   }else{
		        alert("Product already exist -(:");
		        
		        }

		   })
		   .fail(function(response) {

		   		console.log("Oop's Something went wrong..!");
		   		alert(response);
				// Lobibox.alert('error',
				// {
				// 	msg: response
				// });
		   });
		      
		      return false;
		}
	});


});