$(document).ready(function(e){

  if (localStorage.getItem("prm_edit_details") === null) {
    alert("Invalid Action");
    window.location="product-list.html";
  }



  var json = localStorage.getItem("prm_edit_details");
  var prm_edit_details = JSON.parse(json);
  var prm_id = prm_edit_details.prm_id;
  var prm_name = prm_edit_details.prm_name;
  var prm_rate = prm_edit_details.prm_rate;

  $("#id_prm_name").val(prm_name);
  $('#id_prm_rate').val(prm_rate);



    $("#id_saveData").click(function(e) {

    
    var prm_name,prm_rate;
    prm_name=$("#id_prm_name").val();
    prm_rate=$("#id_prm_rate").val();
    

    if(prm_name==null || prm_name=='' || prm_name==undefined){
      alert('Please Select prm_name')
      $('#id_prm_prm_name').focus();
    }
    else if(prm_rate=="" || prm_rate==undefined || prm_rate==null){
      alert('Please Enter prm_rate');
      
      $('#id_prm_rate').focus();
    }   
    else
    {
      $.ajax({
            type: 'POST',
            url: '../php/product-edit.php',
            data: {prm_id : prm_id, prm_name : prm_name, prm_rate : prm_rate}        
       })
      .done(function(response){ 

        // var res = "name Updated";

          // alert(response);
          // console.log(response);
      
            if(response>0){

              localStorage.removeItem("prm_edit_details");              
              alert("Product Updated..!");
              window.location="product-list.html";
              
            }
            else{
              alert("Product not Updated -(:");
            
            }

       })
       .fail(function(response) {

          console.log("Oop's Something went wrong..!");
          alert(response);
        // Lobibox.alert('error',
        // {
        //  msg: response
        // });
       });
          
          return false;
    }
  });

    $("#id_back").click(function(e) {
      window.location="product-list.html";
    });



});