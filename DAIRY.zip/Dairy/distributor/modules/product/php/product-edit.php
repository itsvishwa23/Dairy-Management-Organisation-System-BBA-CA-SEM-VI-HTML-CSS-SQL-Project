<?php
session_start();
require '../../../../common/connection.php';

$prm_id = $_POST['prm_id'];
$prm_name = $_POST['prm_name'];
$prm_rate = $_POST['prm_rate'];


$sql = "UPDATE product_master SET prm_name='".$prm_name."',prm_rate='".$prm_rate."' WHERE prm_id = '".$prm_id."' ";
$result = $conn->query($sql);
echo $result;

$conn->close();

?>

