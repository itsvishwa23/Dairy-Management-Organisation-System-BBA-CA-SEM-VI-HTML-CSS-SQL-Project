<?php
session_start();
require '../../../../common/connection.php';

$i=0;

$sqlCount="SELECT count(*) as total from product_master";
$result = $conn->query($sqlCount);
$data=$result->fetch_assoc();
$count=$data['total'];

$sql="select * from product_master where prm_status = 0";
$result = $conn->query($sql);


	$list = array();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		array_push($list,array(++$i,$row["prm_name"]."<span class='prm_id' style='display:none;'>".$row["prm_id"]."</span>",$row["prm_rate"].".00"."<span class='prm_rate' style='display:none;'>".$row["prm_rate"]."</span>",$row["prm_created_at"]."<span class='prm_name' style='display:none;'>".$row["prm_name"]."</span>","<i style='cursor:pointer;' class='fa fa-pencil-square-o' ></i> &nbsp; <i style='cursor:pointer;' class='fa fa-trash-o'></i>"));     
  
    }
} else {
    echo "0 results";
}

$myJSON = json_encode($list);
  echo $myJSON;
$conn->close();
?>