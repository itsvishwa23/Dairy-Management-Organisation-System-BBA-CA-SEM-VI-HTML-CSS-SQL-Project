<?php
session_start();
require '../../../../common/connection.php';

$prm_id = $_POST['prm_id'];

$sql = "UPDATE product_master SET prm_status=1 WHERE prm_id = $prm_id ";
$result = $conn->query($sql);

if($result){
	echo "Product Deleted";
}
else{
	echo "Product Not Deleted";
}

$conn->close();

?>

