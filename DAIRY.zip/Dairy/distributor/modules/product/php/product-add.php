<?php
session_start();
require '../../../../common/connection.php';


$prm_name=$_POST["prm_name"];
$prm_rate=$_POST["prm_rate"];



$sqlchk = "SELECT prm_name from product_master where prm_name='" .$prm_name. "' and  prm_status=0";
$result = $conn->query($sqlchk);

			if ($result->num_rows > 0) {
				echo "This Product already Exist..!";
			}
			else{
					$sql = "INSERT product_master(prm_name,prm_rate) VALUES ('".$prm_name."','".$prm_rate."')";
					$insert = $conn->query($sql);
					if($insert)
						echo "ok";
					else
						echo "not ok";
			}
$conn->close();
?>