$(document).ready(function(e){

  if (localStorage.getItem("sm_edit_details") === null) {
    alert("Invalid Action");
    window.location="storage-list.html";
  }



  var json = localStorage.getItem("sm_edit_details");
  var sm_edit_details = JSON.parse(json);
  var sm_id = sm_edit_details.sm_id;
  var sm_name = sm_edit_details.sm_name;
  var sm_capacity = sm_edit_details.sm_capacity;  
  var sm_available = sm_edit_details.sm_available;
  var sm_milk_available = sm_edit_details.sm_milk_available;
  var sm_milk_available_old = sm_edit_details.sm_milk_available;
  
  

  $("#id_lbl_storageId").html(sm_id);
  $("#id_txt_sm_name").val(sm_name);
  $('#id_num_sm_capacity').val(sm_capacity);
  $('#id_num_sm_milk_available').val(sm_milk_available);


    $("#id_btnUpdateData").click(function(e) {


      var nameRegex = /^[a-zA-Z ]{2,30}$/;
      var numberRegex = /^[0-9]{1,10}$/;
      var emailRegex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      var mobileNumberRegex = /^\d{10}$/;
      var nameNumberRegex = /[^A-Za-z0-9 .]+/;

    
    var sm_name,sm_capacity,sm_milk_available;
    sm_name=$("#id_txt_sm_name").val();
    sm_capacity=$("#id_num_sm_capacity").val();    
    sm_milk_available=$("#id_num_sm_milk_available").val();
    if($('#id_txt_sm_name').val() == undefined || $('#id_txt_sm_name').val() == "")
        { 
          $("#id_small_sm_name").html("Please Enter Storage Name");
          $("#id_small_sm_name").show().delay(4000).fadeOut();
          $('#id_txt_sm_name').focus();
          return false;
        } 
        else if($('#id_num_sm_capacity').val() == undefined || $('#id_num_sm_capacity').val() == "")
        {     
          $("#id_small_sm_capacity").html("Please Enter Storage Capacity");
          $("#id_small_sm_capacity").show().delay(4000).fadeOut();            
          $('#id_num_sm_capacity').focus();
          return false;
        } 
        else if($('#id_num_sm_milk_available').val() == undefined || $('#id_num_sm_milk_available').val() == "")
        {     
          $("#id_small_sm_milk_available").html("Please Enter Number or 0");
          $("#id_small_sm_milk_available").show().delay(4000).fadeOut();            
          $('#id_num_sm_milk_available').focus();
          return false;
        }           
        else if(nameNumberRegex.test($('#id_txt_sm_name').val())){              
          $("#id_small_sm_name").html("Please Enter valid Storage Name");
          $("#id_small_sm_name").show().delay(4000).fadeOut();
          $('#id_txt_sm_name').focus();
          return false;
        }           
        else if(parseFloat(sm_milk_available) > parseFloat(sm_milk_available_old)){              
          $("#id_small_sm_milk_available").html("Increasing milk Prohibited");
          $("#id_small_sm_milk_available").show().delay(4000).fadeOut();
          $('#id_num_sm_milk_available').focus();
          return false;
        }           
        else if(parseFloat(sm_milk_available) < 0){              
          $("#id_small_sm_milk_available").html("Invalid Number");
          $("#id_small_sm_milk_available").show().delay(4000).fadeOut();
          $('#id_num_sm_milk_available').focus();
          return false;
        } 
    else
    {
      if(parseFloat(sm_milk_available) === parseFloat(sm_milk_available_old))
        sm_available = parseFloat(sm_available)  + parseFloat(0);
      else{
        var sm_milk_available_temp = parseFloat(sm_milk_available_old) - parseFloat(sm_milk_available);
        sm_available = parseFloat(sm_available) + parseFloat(sm_milk_available_temp);
        sm_milk_available = parseFloat(sm_milk_available_old) - parseFloat(sm_milk_available_temp);
      }
      
      
      
      $.ajax({
            type: 'POST',
            url: '../php/storage-edit.php',
            data: {sm_id : sm_id, sm_name : sm_name, sm_capacity : sm_capacity, sm_available : sm_available, sm_milk_available : sm_milk_available}
       })
      .done(function(response){ 
      
            if(response == 1){

              localStorage.removeItem("sm_edit_details");              
              alert("Storage Updated..!");
              window.location="storage-list.html";
              
            }
            else{
              alert("Storage not Updated -(:");
            
            }

       })
       .fail(function(response) {

          console.log("Oop's Something went wrong..!");
          alert(response);
       });
       return false;
    }
  });

    $("#id_back").click(function(e) {
      window.location="storage-list.html";
    });



});