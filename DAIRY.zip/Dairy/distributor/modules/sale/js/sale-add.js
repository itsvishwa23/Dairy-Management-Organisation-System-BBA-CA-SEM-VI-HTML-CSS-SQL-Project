


$(document).ready(function(e){

	var prm_rate,sm_available;
 
	 $('#id_txt_sm_cm_first_name').typeahead({
	  source: function(query, result)
	  {
	   $.ajax({
	    url:"../php/fetch.php",
	    method:"POST",
	    data:{query:query},
	    dataType:"json",
	    success:function(data)
	    {
	     result($.map(data, function(item){
	     	console.log(item[2]);
	      // alert(item);
	      return item[0]+" "+item[1]+" "+item[2]+" "+item[3]+" "+"("+item[4]+")";
	     }));
	    }
	   })
	  }, afterSelect: function (data) {
        //print the data to developer tool's console
        console.log(data);
        }
	 });



       
        // $.ajax({
        //       type: 'POST',
        //       url: '../php/get-storage.php',
        //       data: {}        
        // })
        // .done(function(response){
        //   $("#id_sm_sm_id").html(response);
        // })
        // .fail(function(response) {
        //       console.log(response);
        // });  



        $.ajax({
              type: 'POST',
              url: '../php/get-product.php',
              data: {}        
        })
        .done(function(response){
          $("#id_sm_prm_name").html(response);

        })
        .fail(function(response) {
              console.log(response);
        });




        $("#id_sm_prm_name").change(function(){
        	$.ajax({
              type: 'POST',
              url: '../php/get-productrate-by-id.php',
              data: {prm_id:$("#id_sm_prm_name").val()}        
	        })
	        .done(function(response){
	          $("#id_lbl_sm_prm_rate").html(response);
	          prm_rate = response;
	          calcAmount();
	        })
	        .fail(function(response) {
	              console.log(response);
	        });
		});


        

  //       $("#id_sm_sm_id").change(function(){
  //       	$.ajax({
  //             type: 'POST',
  //             url: '../php/get-storage-by-id.php',
  //             data: {sm_id:$("#id_sm_sm_id").val()}        
	 //        })
	 //        .done(function(response){
	 //          $("#id_lbl_sm_storage_avialability").html(response+' Litre');
	 //          sm_available = response;
	 //          // calcAmount();
	 //        })
	 //        .fail(function(response) {
	 //              console.log(response);
	 //        });
		// });


		$( "#id_num_sm_quantity" ).keyup(function() {

	        // $("#id_lbl_sm_storage_avialability").html('');

			// $.ajax({
   //            type: 'POST',
   //            url: '../php/get-storage-filter.php',
   //            data: {quantity:$("#id_num_sm_quantity").val()}        
	  //       })
	  //       .done(function(response){
	  //         $("#id_sm_sm_id").html(response);
	  //         calcAmount();
	  //       })
	  //       .fail(function(response) {
	  //             console.log(response);
	  //       });  

		  calcAmount();
		});

		function calcAmount(){

			console.log("keypress");

			var quantity = $("#id_num_sm_quantity").val();

	          $("#id_lbl_sm_totalAmount").html(quantity * prm_rate);
		}

	localStorage.removeItem("sm_edit_details"); 
	$("#id_small_sm_name").hide(); 
	// $("#id_small_sm_capacity").hide();                           

	$("#id_btnSaveData").click(function(e) {

		var sm_cm_id, sm_quantity, sm_sm_id, sm_prm_name, sm_prm_rate;

		sm_cm_id = $("#id_txt_sm_cm_first_name").val();
		sm_cm_id = sm_cm_id.split(' ')[0]; 
		sm_quantity = $("#id_num_sm_quantity").val();
		// sm_sm_id = $("#id_sm_sm_id").val();
		sm_prm_name = $("#id_sm_prm_name").val();
		sm_prm_rate = prm_rate;
		
	    var nameRegex = /^[a-zA-Z ]{2,30}$/;
	    var numberRegex = /^[0-9]{1,10}$/;
	    var emailRegex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	    var mobileNumberRegex = /^\d{10}$/;
        var nameNumberRegex = /[^A-Za-z0-9 ]+/;
	 	if($('#id_txt_sm_cm_first_name').val() == undefined || $('#id_txt_sm_cm_first_name').val() == "")
      	{	
      		$("#id_small_sm_cm_first_name").html("Please Search Customer Name");
      		$("#id_small_sm_cm_first_name").show().delay(4000).fadeOut();
      		$('#id_txt_sm_cm_first_name').focus();
      		return false;
      	} 
      	else if($('#id_num_sm_quantity').val() == undefined || $('#id_num_sm_quantity').val() == "")
      	{			
      		$("#id_small_sm_quantity").html("Please Enter quantity");
      		$("#id_small_sm_quantity").show().delay(4000).fadeOut();	      		
      		$('#id_num_sm_quantity').focus();
      		return false;
      	}  
      	// else if($('#id_sm_sm_id').val() == undefined || $('#id_sm_sm_id').val() == "")
      	// {			
      	// 	$("#id_small_sm_storage").html("Please Select Storage");
      	// 	$("#id_small_sm_storage").show().delay(4000).fadeOut();	      		
      	// 	$('#id_sm_sm_id').focus();
      	// 	return false;
      	// } 
      	else if($('#id_sm_prm_name').val() == undefined || $('#id_sm_prm_name').val() == "")
      	{			
      		$("#id_small_sm_prm_name").html("Please Select Product");
      		$("#id_small_sm_prm_name").show().delay(4000).fadeOut();	      		
      		$('#id_sm_prm_name').focus();
      		return false;
      	} 		
		else
		{ 
		  // sm_available = sm_available - sm_quantity;
		  $.ajax({
		        type: 'POST',
		        url: '../php/sale-add.php',
		        data: {sm_cm_id : sm_cm_id, sm_quantity : sm_quantity, sm_prm_name:sm_prm_name, sm_prm_rate:sm_prm_rate}
		   })
		  .done(function(response){ 
		  
		        if(response == 1){
		        alert("Product Sale..!");

				location.reload();
		   }else{
		        alert(response);

		        
		        }
		   })
		   .fail(function(response) {

		   		console.log("Oop's Something went wrong..!");
		   		alert(response);
		   });
		   return false;
		}
	});


});