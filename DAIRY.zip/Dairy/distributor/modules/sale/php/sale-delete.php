<?php
session_start();
require '../../../../common/connection.php';

$sm_id = $_POST['sm_id'];

$sql = "UPDATE storage_master SET sm_status=1 WHERE sm_id = $sm_id ";
$result = $conn->query($sql);

if($result){
	echo "Storage Deleted";
}
else{
	echo "Storage Not Deleted";
}

$conn->close();

?>

