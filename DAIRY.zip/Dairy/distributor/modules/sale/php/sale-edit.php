<?php
session_start();
require '../../../../common/connection.php';
 
$sm_id=$_POST["sm_id"];
$sm_name=$_POST["sm_name"];
$sm_capacity=$_POST["sm_capacity"];
$sm_available=$_POST["sm_available"];
$sm_milk_available=$_POST["sm_milk_available"];


$sql = "UPDATE storage_master SET sm_name='".$sm_name."',sm_capacity='".$sm_capacity."',sm_available='".$sm_available."',sm_milk_available='".$sm_milk_available."' WHERE sm_id = '".$sm_id."' ";
$result = $conn->query($sql);
echo $result;

$conn->close();

?>

