<?php
session_start();

$prm_id=$_POST["prm_id"];
require '../../../../common/connection.php';
$sqlchk = "SELECT prm_rate FROM product_master where prm_id = $prm_id";
$result = $conn->query($sqlchk);

			if ($result->num_rows == 1) {
				$row = $result->fetch_assoc();
				echo $row["prm_rate"];
			}
			else{
				echo "0";
			}
$conn->close();
?>