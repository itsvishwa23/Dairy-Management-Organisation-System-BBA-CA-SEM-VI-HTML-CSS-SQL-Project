<?php
session_start();
$sm_id=$_POST["sm_id"];
require '../../../../common/connection.php';
$sqlchk = "SELECT * FROM storage_master where sm_status = 0 and sm_id = $sm_id";
$result = $conn->query($sqlchk);

			if ($result->num_rows == 1) {
				$row = $result->fetch_assoc();
				echo $row["sm_available"];
    // while($row = $result->fetch_assoc()) {

    // 	echo '<option value='.$row["sm_id"].'>'.$row["sm_name"].'</option>';
    // }
} else {
    echo "0 results";
}
$conn->close();
?>