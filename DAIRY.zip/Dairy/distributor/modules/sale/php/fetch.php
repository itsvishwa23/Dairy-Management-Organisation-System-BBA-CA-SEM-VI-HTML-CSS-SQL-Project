<?php

session_start();
require '../../../../common/connection.php';
$request = mysqli_real_escape_string($conn, $_POST["query"]);
$query = "
 SELECT * FROM customer_master WHERE cm_first_name LIKE '%".$request."%' and cm_status = 0 or cm_last_name LIKE '%".$request."%' and cm_status = 0 ";
$result = mysqli_query($conn, $query);

$data = array();

if(mysqli_num_rows($result) > 0)
{
 while($row = mysqli_fetch_assoc($result))
 {
 	array_push($data,array($row["cm_id"],$row["cm_first_name"],$row["cm_last_name"],$row["cm_address"],$row["cm_mobile"]));
  
 }
 echo json_encode($data);
}

?>
