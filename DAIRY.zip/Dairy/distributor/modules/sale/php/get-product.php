<?php
session_start();
require '../../../../common/connection.php';
$sqlchk = "SELECT * FROM product_master where prm_status = 0";
$result = $conn->query($sqlchk);

			if ($result->num_rows > 0) {
				echo '<option selected disabled>--select--</option>';
    while($row = $result->fetch_assoc()) {

    	echo '<option value='.$row["prm_id"].'>'.$row["prm_name"].'</option>';
    }
} else {
    echo "0 results";
}
$conn->close();
?>