<?php
session_start();
require '../../../../common/connection.php';
$sqlchk = "SELECT * FROM storage_master where sm_status = 0 and sm_available > 0";
$result = $conn->query($sqlchk);

			if ($result->num_rows > 1) {
				echo "<option disabled selected>---select---</option>";
    while($row = $result->fetch_assoc()) {

    	echo '<option value='.$row["sm_id"].'>'.$row["sm_name"].'</option>';
    }
} else {
    echo "0 results";
}
$conn->close();
?>