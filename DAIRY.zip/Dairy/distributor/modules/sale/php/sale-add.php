<?php
session_start();
require '../../../../common/connection.php';
 
$sm_cm_id=$_POST["sm_cm_id"];
$sm_quantity=$_POST["sm_quantity"];
// $sm_sm_id=$_POST["sm_sm_id"];
$sm_prm_name=$_POST["sm_prm_name"];
$sm_prm_rate=$_POST["sm_prm_rate"];
// $sm_available=$_POST["sm_available"];

$sql = "INSERT sale_master(sm_cm_id,sm_quantity,sm_prm_name,sm_prm_rate) VALUES ('".$sm_cm_id."','".$sm_quantity."','".$sm_prm_name."','".$sm_prm_rate."')";

$insert = $conn->query($sql);
if($insert == 1){

	// $sql = "SELECT sm_quantity_available from storage_master where sm_id='" .$sm_sm_id. "'";
	// $result = $conn->query($sql);
	// $row = $result->fetch_assoc();
	// $sm_quantity_available = $row["sm_quantity_available"] + $sm_quantity;

	// $sql = "UPDATE storage_master SET sm_available='".$sm_available."',sm_quantity_available='".$sm_quantity_available."' WHERE sm_id = '".$sm_sm_id."' ";
	// $result = $conn->query($sql);
	echo $insert;
}			
$conn->close();
?>