<?php
session_start();
require '../../../../common/connection.php';
$sqlchk = "SELECT sm_id FROM sale_master ORDER BY sm_id DESC LIMIT 1";
$result = $conn->query($sqlchk);

			if ($result->num_rows == 1) {
				$row = $result->fetch_assoc();
				echo $row["sm_id"];
			}
			else{
				echo "0";
			}
$conn->close();
?>