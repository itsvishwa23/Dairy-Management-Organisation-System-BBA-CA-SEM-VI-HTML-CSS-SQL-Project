<?php
session_start();
require '../../../../common/connection.php';

$i=0;
$sql="SELECT * FROM sale_master sm LEFT OUTER JOIN customer_master cm ON sm.sm_cm_id = cm.cm_id";
$result = $conn->query($sql);

$list = array();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		array_push($list,array(++$i,$row["cm_first_name"],$row["cm_last_name"],$row["cm_mobile"],$row["sm_prm_name"],$row["sm_prm_rate"],$row["sm_quantity"],$row["sm_quantity"] * $row["sm_prm_rate"],$row["sm_created_at"]));
    }
} else {
    echo "0 results";
}


$myJSON = json_encode($list);
echo $myJSON;
$conn->close();
?>