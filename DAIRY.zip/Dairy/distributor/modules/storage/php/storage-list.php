<?php
session_start();
require '../../../../common/connection.php';

$i=0;
$sql="select * from storage_master where sm_status = 0";
$result = $conn->query($sql);

$list = array();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		array_push($list,array(++$i."<span class='sm_id' style='display:none;'>".$row["sm_id"]."</span>",$row["sm_name"]."<span class='sm_name' style='display:none;'>".$row["sm_name"]."</span>",$row["sm_capacity"]." Litre"."<span class='sm_capacity' style='display:none;'>".$row["sm_capacity"]."</span>",$row["sm_available"]." Litre"."<span class='sm_available' style='display:none;'>".$row["sm_available"]."</span>",$row["sm_milk_available"]." Litre"."<span class='sm_milk_available' style='display:none;'>".$row["sm_milk_available"]."</span>",$row["sm_created_at"]."<span class='sm_created_at' style='display:none;'>".$row["sm_created_at"]."</span>","<i style='cursor:pointer;' class='fa fa-pencil-square-o' ></i> &nbsp; <i style='cursor:pointer;' class='fa fa-trash-o'></i>"));
    }
} else {
    echo "0 results";
}


$myJSON = json_encode($list);
echo $myJSON;
$conn->close();
?>