<?php
session_start();
require '../../../../common/connection.php';

 
$sm_name=$_POST["sm_name"];
$sm_capacity=$_POST["sm_capacity"];
$sm_available=$_POST["sm_capacity"];

$sqlchk = "SELECT sm_name from storage_master where sm_name='" .$sm_name. "'";
$result = $conn->query($sqlchk);

			if ($result->num_rows > 0) {
				echo "Storage already exist -(:";
			}
			else{
					$sql = "INSERT storage_master(sm_name,sm_capacity,sm_available) VALUES ('".$sm_name."','".$sm_capacity."','".$sm_capacity."')";
					$insert = $conn->query($sql);
					echo $insert;
			}
$conn->close();
?>