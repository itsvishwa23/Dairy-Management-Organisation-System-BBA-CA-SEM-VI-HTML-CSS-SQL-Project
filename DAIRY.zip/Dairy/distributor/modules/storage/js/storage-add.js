$(document).ready(function(e){

	localStorage.removeItem("sm_edit_details"); 
	$("#id_small_sm_name").hide(); 
	$("#id_small_sm_capacity").hide();                           

	$("#id_btnSaveData").click(function(e) {


	    var nameRegex = /^[a-zA-Z ]{2,30}$/;
	    var numberRegex = /^[0-9]{1,10}$/;
	    var emailRegex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	    var mobileNumberRegex = /^\d{10}$/;
        var nameNumberRegex = /[^A-Za-z0-9 ]+/;

		
		var sm_name,sm_capacity;
		sm_name=$("#id_txt_sm_name").val();
		sm_capacity=$("#id_num_sm_capacity").val();
	 	if($('#id_txt_sm_name').val() == undefined || $('#id_txt_sm_name').val() == "")
      	{	
      		$("#id_small_sm_name").html("Please Enter Storage Name");
      		$("#id_small_sm_name").show().delay(4000).fadeOut();
      		$('#id_txt_sm_name').focus();
      		return false;
      	} 
      	else if($('#id_num_sm_capacity').val() == undefined || $('#id_num_sm_capacity').val() == "")
      	{			
      		$("#id_small_sm_capacity").html("Please Enter Storage Capacity");
      		$("#id_small_sm_capacity").show().delay(4000).fadeOut();	      		
      		$('#id_num_sm_capacity').focus();
      		return false;
      	}        	
      	else if(nameNumberRegex.test($('#id_txt_sm_name').val())){	            
      		$("#id_small_sm_name").html("Please Enter valid Storage Name");
      		$("#id_small_sm_name").show().delay(4000).fadeOut();
      		$('#id_txt_sm_name').focus();
      		return false;
      	}        	
      	// else if(!nameRegex.test($('#id_num_sm_capacity').val())){		
      	// 	$("#id_small_sm_capacity").html("Please Enter valid Name");
      	// 	$("#id_small_sm_capacity").show().delay(4000).fadeOut();
      	// 	$('#id_num_sm_capacity').focus();
      	// 	return false;
      	// } 		
		else
		{
		  
		  $.ajax({
		        type: 'POST',
		        url: '../php/storage-add.php',
		        data: {sm_name : sm_name, sm_capacity : sm_capacity}
		   })
		  .done(function(response){ 
		  
		        if(response == 1){
		        alert("Storage Added Successfully..!");

				location.reload();
		   }else{
		        alert(response);

		        
		        }

		   })
		   .fail(function(response) {

		   		console.log("Oop's Something went wrong..!");
		   		alert(response);
		   });
		   return false;
		}
	});


});