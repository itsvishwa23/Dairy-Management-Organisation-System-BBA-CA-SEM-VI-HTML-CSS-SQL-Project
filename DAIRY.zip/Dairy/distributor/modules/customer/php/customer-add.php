<?php
session_start();
require '../../../../common/connection.php';


$cm_first_name=$_POST["cm_first_name"];
$cm_last_name=$_POST["cm_last_name"];
$cm_email=$_POST["cm_email"];
$cm_password=base64_encode($_POST["cm_password"]);
$cm_mobile=$_POST["cm_mobile"];
$cm_address=$_POST["cm_address"];



$sqlchk = "SELECT cm_mobile from customer_master where cm_mobile='".$cm_mobile."'";
$result = $conn->query($sqlchk);

			if ($result->num_rows > 0) {
				echo "This is Existing Customer..!";
			}
			else{


					$sql = "INSERT customer_master(cm_first_name,cm_last_name,cm_email,cm_password,cm_mobile,cm_address) VALUES ('".$cm_first_name."','".$cm_last_name."','".$cm_email."','".$cm_password."','".$cm_mobile."','".$cm_address."')";
					$insert = $conn->query($sql);
					if($insert)
						echo "ok";
					else
						echo "not ok";
			}
$conn->close();
?>