<?php
session_start();
require '../../../../common/connection.php';

$cm_id=$_POST["cm_id"];
$cm_first_name=$_POST["cm_first_name"];
$cm_last_name=$_POST["cm_last_name"];
$cm_email=$_POST["cm_email"];
$cm_password=base64_encode($_POST["cm_password"]);
$cm_mobile=$_POST["cm_mobile"];
$cm_address=$_POST["cm_address"];


$sql = "UPDATE customer_master SET cm_first_name='".$cm_first_name."',cm_last_name='".$cm_last_name."',cm_email='".$cm_email."',cm_password='".$cm_password."',cm_mobile='".$cm_mobile."',cm_address='".$cm_address."' WHERE cm_id = '".$cm_id."' ";
$result = $conn->query($sql);
echo $result;

$conn->close();

?>

