<?php
session_start();
require '../../../../common/connection.php';

$i=0;

// $sqlCount="SELECT count(*) as total from customer_master";
// $result = $conn->query($sqlCount);
// $data=$result->fetch_assoc();
// $count=$data['total'];

$sql="select * from customer_master where cm_status = 0";
$result = $conn->query($sql);

$list = array();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		array_push($list,array(++$i,$row["cm_id"]."<span class='cm_id' style='display:none;'>".$row["cm_id"]."</span>",$row["cm_first_name"]."<span class='cm_first_name' style='display:none;'>".$row["cm_first_name"]."</span>",$row["cm_last_name"]."<span class='cm_last_name' style='display:none;'>".$row["cm_last_name"]."</span>",$row["cm_email"]."<span class='cm_email' style='display:none;'>".$row["cm_email"]."</span>",base64_decode($row["cm_password"])."<span class='cm_password' style='display:none;'>".base64_decode($row["cm_password"])."</span>",$row["cm_mobile"]."<span class='cm_mobile' style='display:none;'>".$row["cm_mobile"]."</span>",$row["cm_address"]."<span class='cm_address' style='display:none;'>".$row["cm_address"]."</span>",$row["cm_created_at"]."<span class='cm_created_at' style='display:none;'>".$row["cm_created_at"]."</span>","<i style='cursor:pointer;' class='fa fa-pencil-square-o' ></i> &nbsp; <i style='cursor:pointer;' class='fa fa-trash-o'></i>"));
    }
} else {
    echo "0 results";
}


$myJSON = json_encode($list);

echo $myJSON;
$conn->close();
?>