<?php
session_start();
require '../../../../common/connection.php';

$cm_id = $_POST['cm_id'];

$sql = "UPDATE customer_master SET cm_status=1 WHERE cm_id = $cm_id ";
$result = $conn->query($sql);

if($result){
	echo "Customer Deleted";
}
else{
	echo "Customer Not Deleted";
}

$conn->close();

?>

