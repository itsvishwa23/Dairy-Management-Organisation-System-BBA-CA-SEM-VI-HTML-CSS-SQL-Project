<?php
session_start();
require '../../../../common/connection.php';
$sqlchk = "SELECT cm_id FROM customer_master ORDER BY cm_id DESC LIMIT 1";
$result = $conn->query($sqlchk);

			if ($result->num_rows == 1) {
				$row = $result->fetch_assoc();
				echo $row["cm_id"];
			}
			else{
				echo "0";
			}
$conn->close();
?>