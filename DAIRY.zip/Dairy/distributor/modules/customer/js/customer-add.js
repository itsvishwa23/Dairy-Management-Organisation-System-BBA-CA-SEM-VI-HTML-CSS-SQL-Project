$(document).ready(function(e){

	localStorage.removeItem("cm_edit_details"); 
	$("#id_small_cm_firstName").hide(); 
	$("#id_small_cm_lastName").hide();   
	$("#id_small_cm_email").hide(); 
	$("#id_small_cm_password").hide();  
	$("#id_small_cm_mobile").hide(); 
	$("#id_small_cm_address").hide();                           

	$("#id_btnSaveData").click(function(e) {


	    var nameRegex = /^[a-zA-Z ]{2,30}$/;
	    var numberRegex = /^[0-9]{1,10}$/;
	    var emailRegex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	    var mobileNumberRegex = /^\d{10}$/;

		
		var cm_first_name,cm_last_name,cm_email,cm_password,cm_mobile,cm_address;
		cm_first_name=$("#id_txt_cm_firstName").val();
		cm_last_name=$("#id_txt_cm_lastName").val();
		cm_email=$("#id_txt_cm_email").val();
		cm_password=$("#id_txt_cm_password").val();
		cm_mobile=$("#id_txt_cm_mobile").val();
		cm_address=$("#id_txtArea_cm_address").val();

	 	if($('#id_txt_cm_firstName').val() == undefined || $('#id_txt_cm_firstName').val() == "")
      	{	
      		$("#id_small_cm_firstName").html("Please Enter First Name");
      		$("#id_small_cm_firstName").show().delay(4000).fadeOut();
      		$('#id_txt_cm_firstName').focus();
      		return false;
      	} 
      	else if($('#id_txt_cm_lastName').val() == undefined || $('#id_txt_cm_lastName').val() == "")
      	{			
      		$("#id_small_cm_lastName").html("Please Enter Last Name");
      		$("#id_small_cm_lastName").show().delay(4000).fadeOut();	      		
      		$('#id_txt_cm_lastName').focus();
      		return false;
      	} 
      	else if($('#id_txt_cm_email').val() == undefined || $('#id_txt_cm_email').val() == "")
      	{			
      		$("#id_small_cm_email").html("Please Enter Email");
      		$("#id_small_cm_email").show().delay(4000).fadeOut();
      		$('#id_txt_cm_email').focus();
      		return false;
      	} 
      	else if($('#id_txt_cm_password').val() == undefined || $('#id_txt_cm_password').val() == "")
      	{			
      		$("#id_small_cm_password").html("Please Enter Password");
      		$("#id_small_cm_password").show().delay(4000).fadeOut();
      		$('#id_txt_cm_password').focus();
      		return false;
      	}  
      	else if($('#id_txt_cm_mobile').val() == undefined || $('#id_txt_cm_mobile').val() == "")
      	{			
      		$("#id_small_cm_mobile").html("Please Enter Mobile");
      		$("#id_small_cm_mobile").show().delay(4000).fadeOut();
      		$('#id_txt_cm_mobile').focus();
      		return false;
      	}  
      	else if($('#id_txt_cm_password').val() == undefined || $('#id_txt_cm_password').val() == "")
      	{			
      		$("#id_small_cm_password").html("Please Enter Password");
      		$("#id_small_cm_password").show().delay(4000).fadeOut();
      		$('#id_txt_cm_password').focus();
      		return false;
      	}       	 
      	else if($('#id_txtArea_cm_address').val() == undefined || $('#id_txtArea_cm_address').val() == "")
      	{			
      		$("#id_small_cm_address").html("Please Enter Address");
      		$("#id_small_cm_address").show().delay(4000).fadeOut();
      		$('#id_txtArea_cm_address').focus();
      		return false;
      	}       	
      	else if(!nameRegex.test($('#id_txt_cm_firstName').val())){		
      		$("#id_small_cm_firstName").html("Please Enter valid Name");
      		$("#id_small_cm_firstName").show().delay(4000).fadeOut();
      		$('#id_txt_cm_firstName').focus();
      		return false;
      	}        	
      	else if(!nameRegex.test($('#id_txt_cm_lastName').val())){		
      		$("#id_small_cm_lastName").html("Please Enter valid Name");
      		$("#id_small_cm_lastName").show().delay(4000).fadeOut();
      		$('#id_txt_cm_lastName').focus();
      		return false;
      	}       	
      	else if(!emailRegex.test($('#id_txt_cm_email').val())){		
      		$("#id_small_cm_email").html("Please Enter valid Email");
      		$("#id_small_cm_email").show().delay(4000).fadeOut();
      		$('#id_txt_cm_email').focus();
      		return false;
      	}        	
      	else if(!mobileNumberRegex.test($('#id_txt_cm_mobile').val())){		
      		$("#id_small_cm_mobile").html("Please Enter valid Mobile");
      		$("#id_small_cm_mobile").show().delay(4000).fadeOut();
      		$('#id_txt_cm_mobile').focus();
      		return false;
      	} 		
		else
		{
		  var data = {cm_first_name : cm_first_name, cm_last_name : cm_last_name, cm_email : cm_email, cm_password : cm_password, cm_mobile : cm_mobile, cm_address : cm_address};        
		  $.ajax({
		        type: 'POST',
		        url: '../php/customer-add.php',
		        data: data
		   })
		  .done(function(response){ 
		  
		        if(response == "ok"){
		        alert("Customer Added Successfully..!");
				location.reload();
		   }else{
		        alert("Customer already exist -(:");
                    alert(response);
                    console.log(response);
		        
		        }

		   })
		   .fail(function(response) {

		   		console.log("Oop's Something went wrong..!");
		   		alert(response);
		   });
		   return false;
		}
	});


});