$(document).ready(function(e){

  localStorage.removeItem("cm_edit_details");              

	$.ajax({
          type: 'POST',
          url: '../php/customer-list.php'
          
  	})
  .done(function(data){ 

    
    
    var dataSet=JSON.parse(data);

    $('#id_list').DataTable( {
        data: dataSet,
        columns: [
            {"className": "dt-center", title: "SR NO" },
            {"className": "dt-center", title: "customer Id" },
            {"className": "dt-center", title: "First Name" },
            {"className": "dt-center", title: "Last Name" },
            {"className": "dt-center", title: "Email" },
            {"className": "dt-center", title: "Password" },
            {"className": "dt-center", title: "Mobile" },
            {"className": "dt-center", title: "Address" },
            {"className": "dt-center", title: "Joining Date" },
            {"className": "dt-center", title: "Action" }
        ]
    } );
  })
  .fail(function(data) {
    alert("oop's something went wrong");
  });  

  $("#id_list").on("click", ".fa-pencil-square-o", (function (ev){
    
    
    
    var cm_id,cm_first_name,cm_last_name,cm_email,cm_password,cm_mobile,cm_address,cm_created_at;
    cm_id = $(this).parent().parent().children().children(".cm_id").html();
    cm_first_name = $(this).parent().parent().children().children(".cm_first_name").html();
    cm_last_name = $(this).parent().parent().children().children(".cm_last_name").html();
    cm_email = $(this).parent().parent().children().children(".cm_email").html();
    cm_password = $(this).parent().parent().children().children(".cm_password").html();
    cm_mobile = $(this).parent().parent().children().children(".cm_mobile").html();
    cm_address = $(this).parent().parent().children().children(".cm_address").html();
    cm_created_at = $(this).parent().parent().children().children(".cm_created_at").html();
    
    
    var cm_edit_details = { "cm_id" : cm_id, "cm_first_name" : cm_first_name, "cm_last_name" : cm_last_name, "cm_email" : cm_email, "cm_password" : cm_password, "cm_mobile" : cm_mobile, "cm_address" : cm_address, "cm_created_at" : cm_created_at};
    var myJSON = JSON.stringify(cm_edit_details);    
    localStorage.setItem("cm_edit_details", myJSON);

    if (localStorage.getItem("cm_edit_details") != null) {
	  window.location="customer-edit.html";
	}
    }));



  $("#id_list").on("click", ".fa-trash-o", (function (ev){
    
    
    
    var cm_id;
    cm_id = $(this).parent().parent().children().children(".cm_id").html();

    if (cm_id != null || cm_id !='' || cm_id !=undefined) {
    	if (confirm("Are you sure want to delete this customer?")) {

    
			    $.ajax({
			      type: 'POST',
			      url: '../php/customer-delete.php',
			      data: {cm_id:cm_id}
			    })
			    .done(function(data){
			    	alert(data); 
			    	location.reload();			      
			    })
			    .fail(function(data) {
			      alert(data);
			    });
		}
    }
    else{
    	alert("Invalid Action..!");
    }
    }));



});