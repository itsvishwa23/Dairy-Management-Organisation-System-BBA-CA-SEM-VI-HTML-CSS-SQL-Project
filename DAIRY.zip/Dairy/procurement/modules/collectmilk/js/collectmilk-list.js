$(document).ready(function(e){

  var dataSet,columns;

  localStorage.removeItem("sm_edit_details");              

	$.ajax({
          type: 'POST',
          url: '../php/collectmilk-list.php'
          
  	})
  .done(function(data){ 
    
    dataSet=JSON.parse(data);
    $('#id_list').DataTable( {
        data: dataSet,
        columns: [
            {"className": "dt-center", title: "SR NO" },
            // {"className": "dt-center", title: "Storage Id" },
            {"className": "dt-center", title: "First Name" },
            {"className": "dt-center", title: "Last Name" },
            {"className": "dt-center", title: "Mobile" },
            {"className": "dt-center", title: "Milk(Litre)" },
            {"className": "dt-center", title: "Milk SNF" },
            {"className": "dt-center", title: "Milk Rate" },
            {"className": "dt-center", title: "Total Amount" },
            {"className": "dt-center", title: "Tank" },
            {"className": "dt-center", title: "Date" },
            // {"className": "dt-center", title: "Date" }
        ],
        dom: 'lBfrtip',
        buttons: [

                { extend: 'pdf', className: 'btn btn-primary glyphicon glyphicon-file' }
            // 'pdf'
        ]
        // buttons: [
        //     {
        //         extend: 'pdf',
        //         customize: function ( win ) {
        //             $(win.document.body)
        //                 .css( 'font-size', '10pt' )
        //                 .prepend(
        //                     '<img src="http://datatables.net/media/images/logo-fade.png" style="position:absolute; top:0; left:0;" />'
        //                 );
 
        //             $(win.document.body).find( 'table' )
        //                 .addClass( 'compact' )
        //                 .css( 'font-size', 'inherit' );
        //         }
        //     }
        // ]
        // buttons: [
        //     'copy', 'csv', 'excel', 'pdf', 'print'
        // ]
    } );
  })
  .fail(function(data) {
    alert(data);
  }); 



 

  









  $("#id_list").on("click", ".fa-pencil-square-o", (function (ev){
    
    var sm_id,sm_name,sm_capacity,sm_available,sm_milk_available;
    sm_id = $(this).parent().parent().children().children(".sm_id").html();
    sm_name = $(this).parent().parent().children().children(".sm_name").html();
    sm_capacity = $(this).parent().parent().children().children(".sm_capacity").html();
    sm_available = $(this).parent().parent().children().children(".sm_available").html();
    sm_milk_available = $(this).parent().parent().children().children(".sm_milk_available").html();
    
    var sm_edit_details = { "sm_id" : sm_id, "sm_name" : sm_name, "sm_capacity" : sm_capacity, sm_available : sm_available, "sm_milk_available" : sm_milk_available};
    var myJSON = JSON.stringify(sm_edit_details);    
    localStorage.setItem("sm_edit_details", myJSON);

    if (localStorage.getItem("sm_edit_details") != null) {
	  window.location="storage-edit.html";
	}
    }));



  $("#id_list").on("click", ".fa-trash-o", (function (ev){
    
    
    
    var sm_id;
    sm_id = $(this).parent().parent().children().children(".sm_id").html();

    if (sm_id != null || sm_id !='' || sm_id !=undefined) {
    	if (confirm("Are you sure want to delete this Storage?")) {

    
			    $.ajax({
			      type: 'POST',
			      url: '../php/storage-delete.php',
			      data: {sm_id:sm_id}
			    })
			    .done(function(data){
			    	alert(data); 
			    	location.reload();			      
			    })
			    .fail(function(data) {
			      alert(data);
			    });
		}
    }
    else{
    	alert("Invalid Action..!");
    }
    }));



});