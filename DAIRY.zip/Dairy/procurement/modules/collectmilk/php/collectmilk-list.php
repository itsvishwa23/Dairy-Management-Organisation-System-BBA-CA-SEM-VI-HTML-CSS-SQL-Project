<?php
session_start();
require '../../../../common/connection.php';

$i=0;
$sql="SELECT * FROM bill_farmer bf LEFT OUTER JOIN farmer_master fm ON bf.bf_fm_id = fm.fm_id LEFT OUTER JOIN storage_master sm on bf.bf_sm_id = sm.sm_id";
$result = $conn->query($sql);

$list = array();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		array_push($list,array(++$i,$row["fm_first_name"],$row["fm_last_name"],$row["fm_mobile"],$row["bf_milk"]." Litre",$row["bf_mrm_snf"],$row["bf_mrm_rate"],$row["bf_milk"] * $row["bf_mrm_rate"],$row["sm_name"],$row["bf_created_at"]));
    }
} else {
    echo "0 results";
}


$myJSON = json_encode($list);
echo $myJSON;
$conn->close();
?>