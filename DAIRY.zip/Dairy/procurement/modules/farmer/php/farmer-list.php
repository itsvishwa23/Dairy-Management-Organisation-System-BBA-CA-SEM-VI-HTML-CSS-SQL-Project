<?php
session_start();
require '../../../../common/connection.php';

$i=0;

$sqlCount="SELECT count(*) as total from farmer_master";
$result = $conn->query($sqlCount);
$data=$result->fetch_assoc();
$count=$data['total'];

$sql="select * from farmer_master where fm_status = 0";
$result = $conn->query($sql);

$list = array();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		array_push($list,array(++$i,$row["fm_id"]."<span class='fm_id' style='display:none;'>".$row["fm_id"]."</span>",$row["fm_first_name"]."<span class='fm_first_name' style='display:none;'>".$row["fm_first_name"]."</span>",$row["fm_last_name"]."<span class='fm_last_name' style='display:none;'>".$row["fm_last_name"]."</span>",$row["fm_email"]."<span class='fm_email' style='display:none;'>".$row["fm_email"]."</span>",base64_decode($row["fm_password"])."<span class='fm_password' style='display:none;'>".base64_decode($row["fm_password"])."</span>",$row["fm_mobile"]."<span class='fm_mobile' style='display:none;'>".$row["fm_mobile"]."</span>",$row["fm_address"]."<span class='fm_address' style='display:none;'>".$row["fm_address"]."</span>",$row["fm_created_at"]."<span class='fm_created_at' style='display:none;'>".$row["fm_created_at"]."</span>","<i style='cursor:pointer;' class='fa fa-pencil-square-o' ></i> &nbsp; <i style='cursor:pointer;' class='fa fa-trash-o'></i>"));
    }
} else {
    echo "0 results";
}


$myJSON = json_encode($list);
echo $myJSON;
$conn->close();
?>