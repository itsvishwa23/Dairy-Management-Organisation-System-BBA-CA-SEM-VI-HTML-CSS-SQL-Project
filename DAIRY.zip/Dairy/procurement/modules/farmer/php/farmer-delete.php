<?php
session_start();
require '../../../../common/connection.php';

$fm_id = $_POST['fm_id'];

$sql = "UPDATE farmer_master SET fm_status=1 WHERE fm_id = $fm_id ";
$result = $conn->query($sql);

if($result){
	echo "Farmer Deleted";
}
else{
	echo "Farmer Not Deleted";
}

$conn->close();

?>

