<?php
session_start();
require '../../../../common/connection.php';


$fm_first_name=$_POST["fm_first_name"];
$fm_last_name=$_POST["fm_last_name"];
$fm_email=$_POST["fm_email"];
// $fm_password=MD5($_POST["fm_password"]);
$fm_password=base64_encode($_POST["fm_password"]);
$fm_mobile=$_POST["fm_mobile"];
$fm_address=$_POST["fm_address"];



$sqlchk = "SELECT fm_mobile from farmer_master where fm_mobile='" .$fm_mobile. "'";
$result = $conn->query($sqlchk);

			if ($result->num_rows > 0) {
				echo "This is Existing Farmer..!";
			}
			else{
					$sql = "INSERT farmer_master(fm_first_name,fm_last_name,fm_email,fm_password,fm_mobile,fm_address) VALUES ('".$fm_first_name."','".$fm_last_name."','".$fm_email."','".$fm_password."','".$fm_mobile."','".$fm_address."')";
					$insert = $conn->query($sql);
					if($insert)
						echo "ok";
					else
						echo "not ok";
			}
$conn->close();
?>