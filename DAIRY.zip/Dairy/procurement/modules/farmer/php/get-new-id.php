<?php
session_start();
require '../../../../common/connection.php';
$sqlchk = "SELECT fm_id FROM farmer_master ORDER BY fm_id DESC LIMIT 1";
$result = $conn->query($sqlchk);

			if ($result->num_rows == 1) {
				$row = $result->fetch_assoc();
				echo $row["fm_id"];
			}
			else{
				echo "0";
			}
$conn->close();
?>