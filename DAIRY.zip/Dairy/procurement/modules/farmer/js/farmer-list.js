$(document).ready(function(e){

  localStorage.removeItem("fm_edit_details");              

	$.ajax({
          type: 'POST',
          url: '../php/farmer-list.php'
          
  	})
  .done(function(data){ 
    
    var dataSet=JSON.parse(data);
    var dataSet2 = [["Tiger Nixon","System Architect","Edinburgh"],
      ["Garrett Winters","Accountant","Tokyo"],
      ["Ashton Cox","Junior Technical Author","San Francisco"]];

    $('#id_list').DataTable( {
        data: dataSet,
        columns: [
            {"className": "dt-center", title: "SR NO" },
            {"className": "dt-center", title: "Farmer Id" },
            {"className": "dt-center", title: "First Name" },
            {"className": "dt-center", title: "Last Name" },
            {"className": "dt-center", title: "Email" },
            {"className": "dt-center", title: "Password" },
            {"className": "dt-center", title: "Mobile" },
            {"className": "dt-center", title: "Address" },
            {"className": "dt-center", title: "Joining Date" },
            {"className": "dt-center", title: "Action" }
        ]
    } );
  })
  .fail(function(data) {
    alert(data);
  });  

  $("#id_list").on("click", ".fa-pencil-square-o", (function (ev){
    
    
    
    var fm_id,fm_first_name,fm_last_name,fm_email,fm_password,fm_mobile,fm_address,fm_created_at;
    fm_id = $(this).parent().parent().children().children(".fm_id").html();
    fm_first_name = $(this).parent().parent().children().children(".fm_first_name").html();
    fm_last_name = $(this).parent().parent().children().children(".fm_last_name").html();
    fm_email = $(this).parent().parent().children().children(".fm_email").html();
    fm_password = $(this).parent().parent().children().children(".fm_password").html();
    fm_mobile = $(this).parent().parent().children().children(".fm_mobile").html();
    fm_address = $(this).parent().parent().children().children(".fm_address").html();
    fm_created_at = $(this).parent().parent().children().children(".fm_created_at").html();
    
    
    var fm_edit_details = { "fm_id" : fm_id, "fm_first_name" : fm_first_name, "fm_last_name" : fm_last_name, "fm_email" : fm_email, "fm_password" : fm_password, "fm_mobile" : fm_mobile, "fm_address" : fm_address, "fm_created_at" : fm_created_at};
    var myJSON = JSON.stringify(fm_edit_details);    
    localStorage.setItem("fm_edit_details", myJSON);

    if (localStorage.getItem("fm_edit_details") != null) {
	  window.location="farmer-edit.html";
	}
    }));



  $("#id_list").on("click", ".fa-trash-o", (function (ev){
    
    
    
    var fm_id;
    fm_id = $(this).parent().parent().children().children(".fm_id").html();

    if (fm_id != null || fm_id !='' || fm_id !=undefined) {
    	if (confirm("Are you sure want to delete this Farmer?")) {

    
			    $.ajax({
			      type: 'POST',
			      url: '../php/farmer-delete.php',
			      data: {fm_id:fm_id}
			    })
			    .done(function(data){
			    	alert(data); 
			    	location.reload();			      
			    })
			    .fail(function(data) {
			      alert(data);
			    });
		}
    }
    else{
    	alert("Invalid Action..!");
    }
    }));



});