$(document).ready(function(e){

	localStorage.removeItem("fm_edit_details"); 
	$("#id_small_fm_firstName").hide(); 
	$("#id_small_fm_lastName").hide();   
	$("#id_small_fm_email").hide(); 
	$("#id_small_fm_password").hide();  
	$("#id_small_fm_mobile").hide(); 
	$("#id_small_fm_address").hide();                           

	$("#id_btnSaveData").click(function(e) {


	    var nameRegex = /^[a-zA-Z ]{2,30}$/;
	    var numberRegex = /^[0-9]{1,10}$/;
	    var emailRegex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	    var mobileNumberRegex = /^\d{10}$/;

		
		var fm_first_name,fm_last_name,fm_email,fm_password,fm_mobile,fm_address;
		fm_first_name=$("#id_txt_fm_firstName").val();
		fm_last_name=$("#id_txt_fm_lastName").val();
		fm_email=$("#id_txt_fm_email").val();
		fm_password=$("#id_txt_fm_password").val();
		fm_mobile=$("#id_txt_fm_mobile").val();
		fm_address=$("#id_txtArea_fm_address").val();

	 	if($('#id_txt_fm_firstName').val() == undefined || $('#id_txt_fm_firstName').val() == "")
      	{	
      		$("#id_small_fm_firstName").html("Please Enter First Name");
      		$("#id_small_fm_firstName").show().delay(4000).fadeOut();
      		$('#id_txt_fm_firstName').focus();
      		return false;
      	} 
      	else if($('#id_txt_fm_lastName').val() == undefined || $('#id_txt_fm_lastName').val() == "")
      	{			
      		$("#id_small_fm_lastName").html("Please Enter Last Name");
      		$("#id_small_fm_lastName").show().delay(4000).fadeOut();	      		
      		$('#id_txt_fm_lastName').focus();
      		return false;
      	} 
      	else if($('#id_txt_fm_email').val() == undefined || $('#id_txt_fm_email').val() == "")
      	{			
      		$("#id_small_fm_email").html("Please Enter Email");
      		$("#id_small_fm_email").show().delay(4000).fadeOut();
      		$('#id_txt_fm_email').focus();
      		return false;
      	} 
      	else if($('#id_txt_fm_password').val() == undefined || $('#id_txt_fm_password').val() == "")
      	{			
      		$("#id_small_fm_password").html("Please Enter Password");
      		$("#id_small_fm_password").show().delay(4000).fadeOut();
      		$('#id_txt_fm_password').focus();
      		return false;
      	}  
      	else if($('#id_txt_fm_mobile').val() == undefined || $('#id_txt_fm_mobile').val() == "")
      	{			
      		$("#id_small_fm_mobile").html("Please Enter Mobile");
      		$("#id_small_fm_mobile").show().delay(4000).fadeOut();
      		$('#id_txt_fm_mobile').focus();
      		return false;
      	}  
      	else if($('#id_txt_fm_password').val() == undefined || $('#id_txt_fm_password').val() == "")
      	{			
      		$("#id_small_fm_password").html("Please Enter Password");
      		$("#id_small_fm_password").show().delay(4000).fadeOut();
      		$('#id_txt_fm_password').focus();
      		return false;
      	}       	 
      	else if($('#id_txtArea_fm_address').val() == undefined || $('#id_txtArea_fm_address').val() == "")
      	{			
      		$("#id_small_fm_address").html("Please Enter Address");
      		$("#id_small_fm_address").show().delay(4000).fadeOut();
      		$('#id_txtArea_fm_address').focus();
      		return false;
      	}       	
      	else if(!nameRegex.test($('#id_txt_fm_firstName').val())){		
      		$("#id_small_fm_firstName").html("Please Enter valid Name");
      		$("#id_small_fm_firstName").show().delay(4000).fadeOut();
      		$('#id_txt_fm_firstName').focus();
      		return false;
      	}        	
      	else if(!nameRegex.test($('#id_txt_fm_lastName').val())){		
      		$("#id_small_fm_lastName").html("Please Enter valid Name");
      		$("#id_small_fm_lastName").show().delay(4000).fadeOut();
      		$('#id_txt_fm_lastName').focus();
      		return false;
      	}       	
      	else if(!emailRegex.test($('#id_txt_fm_email').val())){		
      		$("#id_small_fm_email").html("Please Enter valid Email");
      		$("#id_small_fm_email").show().delay(4000).fadeOut();
      		$('#id_txt_fm_email').focus();
      		return false;
      	}        	
      	else if(!mobileNumberRegex.test($('#id_txt_fm_mobile').val())){		
      		$("#id_small_fm_mobile").html("Please Enter valid Mobile");
      		$("#id_small_fm_mobile").show().delay(4000).fadeOut();
      		$('#id_txt_fm_mobile').focus();
      		return false;
      	} 		
		else
		{
		  var data = {fm_first_name : fm_first_name, fm_last_name : fm_last_name, fm_email : fm_email, fm_password : fm_password, fm_mobile : fm_mobile, fm_address : fm_address};        
		  $.ajax({
		        type: 'POST',
		        url: '../php/farmer-add.php',
		        data: data
		   })
		  .done(function(response){ 
		  
		        if(response == "ok"){
		        alert("Farmer Added Successfully..!");
				location.reload();
		   }else{
		        alert("Farmer already exist -(:");
		        
		        }

		   })
		   .fail(function(response) {

		   		console.log("Oop's Something went wrong..!");
		   		alert(response);
		   });
		   return false;
		}
	});


});