-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 25, 2020 at 05:26 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.0.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dairydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `bill_farmer`
--

CREATE TABLE `bill_farmer` (
  `bf_id` int(11) NOT NULL,
  `bf_fm_id` int(11) NOT NULL,
  `bf_milk` double NOT NULL,
  `bf_sm_id` int(11) NOT NULL,
  `bf_mrm_snf` int(11) NOT NULL,
  `bf_mrm_rate` double NOT NULL,
  `bf_status` int(11) NOT NULL DEFAULT '0',
  `bf_created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `bf_updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bill_farmer`
--

INSERT INTO `bill_farmer` (`bf_id`, `bf_fm_id`, `bf_milk`, `bf_sm_id`, `bf_mrm_snf`, `bf_mrm_rate`, `bf_status`, `bf_created_at`, `bf_updated_at`) VALUES
(1, 20206, 100, 2, 5, 38, 0, '2020-01-18 14:13:33', '2020-01-18 19:48:25'),
(2, 20207, 100, 3, 5, 38, 0, '2020-01-18 14:14:43', '2020-01-18 19:48:39'),
(3, 20206, 10, 2, 1, 11, 0, '2020-01-18 14:19:05', '2020-01-18 19:50:29'),
(4, 20206, 100, 2, 6, 40, 0, '2020-01-18 15:48:40', '2020-01-18 21:18:40'),
(5, 20206, 100, 2, 6, 40, 0, '2020-01-18 15:50:45', '2020-01-18 21:20:45'),
(6, 20209, 15, 2, 4, 19, 0, '2020-01-25 19:50:53', '2020-01-25 11:50:53'),
(7, 20206, 15, 2, 9, 46, 0, '2020-01-29 06:34:14', '2020-01-28 22:34:14'),
(12, 20214, 150, 2, 6, 40, 0, '2020-02-17 08:16:31', '2020-02-17 13:46:31');

-- --------------------------------------------------------

--
-- Table structure for table `customer_master`
--

CREATE TABLE `customer_master` (
  `cm_id` int(11) NOT NULL,
  `cm_first_name` varchar(255) NOT NULL,
  `cm_last_name` varchar(255) NOT NULL,
  `cm_email` varchar(255) NOT NULL,
  `cm_password` varchar(255) NOT NULL,
  `cm_mobile` varchar(15) NOT NULL,
  `cm_address` text NOT NULL,
  `cm_status` int(11) NOT NULL DEFAULT '0',
  `cm_created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cm_updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_master`
--

INSERT INTO `customer_master` (`cm_id`, `cm_first_name`, `cm_last_name`, `cm_email`, `cm_password`, `cm_mobile`, `cm_address`, `cm_status`, `cm_created_at`, `cm_updated_at`) VALUES
(1, 'test', 'test', 'test@gmail.com', 'MTIz', '9458258742', 'CAmp', 0, '2020-02-09 19:52:09', '2020-02-10 02:02:48'),
(2, 'cusomerr', 'customerr', 'customerr@gmail.com', 'MTIzMw==', '9420274444', 'Camp', 0, '2020-02-09 20:12:39', '2020-02-10 02:10:31'),
(3, 'cusomer', 'customer', 'customer@gmail.com', 'MTIz', '9420274579', 'MHAPRAL ISLAMPUR, MANDANGAD, RATNAGIRI', 1, '2020-02-09 20:13:27', '2020-02-10 02:04:16');

-- --------------------------------------------------------

--
-- Table structure for table `distributor_master`
--

CREATE TABLE `distributor_master` (
  `dm_id` int(11) NOT NULL,
  `dm_first_name` varchar(21) NOT NULL,
  `dm_last_name` varchar(21) NOT NULL,
  `dm_email` varchar(255) NOT NULL,
  `dm_password` varchar(255) NOT NULL,
  `dm_mobile` varchar(15) NOT NULL,
  `dm_address` text NOT NULL,
  `dm_status` int(11) DEFAULT '0',
  `dm_created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dm_updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `distributor_master`
--

INSERT INTO `distributor_master` (`dm_id`, `dm_first_name`, `dm_last_name`, `dm_email`, `dm_password`, `dm_mobile`, `dm_address`, `dm_status`, `dm_created_at`, `dm_updated_at`) VALUES
(1, 'Distributor', 'DistriButor', 'distributor@gmail.com', '1234', '1122338877', 'Camp', 0, '2020-02-09 18:03:48', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `employee_leaves`
--

CREATE TABLE `employee_leaves` (
  `el_id` int(11) NOT NULL,
  `el_date` date NOT NULL,
  `el_em_id` int(11) NOT NULL,
  `el_payment_status` varchar(21) NOT NULL DEFAULT 'unpaid',
  `el_status` int(11) NOT NULL DEFAULT '0',
  `el_created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `el_updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee_leaves`
--

INSERT INTO `employee_leaves` (`el_id`, `el_date`, `el_em_id`, `el_payment_status`, `el_status`, `el_created_at`, `el_updated_at`) VALUES
(1, '2020-01-26', 2, 'paid', 0, '2020-01-28 09:46:51', '2020-01-31 20:34:23'),
(2, '2020-01-27', 2, 'paid', 0, '2020-01-28 23:03:25', '2020-01-31 20:34:23'),
(3, '2020-02-19', 3, 'paid', 0, '2020-02-17 08:18:28', '2020-02-29 12:14:23');

-- --------------------------------------------------------

--
-- Table structure for table `employee_master`
--

CREATE TABLE `employee_master` (
  `em_id` int(11) NOT NULL,
  `em_first_name` varchar(21) NOT NULL,
  `em_last_name` varchar(21) NOT NULL,
  `em_email` varchar(255) NOT NULL,
  `em_password` varchar(255) NOT NULL,
  `em_mobile` varchar(15) NOT NULL,
  `em_address` text NOT NULL,
  `em_status` int(11) NOT NULL DEFAULT '0',
  `em_created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `em_updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee_master`
--

INSERT INTO `employee_master` (`em_id`, `em_first_name`, `em_last_name`, `em_email`, `em_password`, `em_mobile`, `em_address`, `em_status`, `em_created_at`, `em_updated_at`) VALUES
(1, 'Ramesh', 'Gaikawad', 'ramesh@gmail.com', 'MTIz', '1122334455', 'Camp', 1, '2020-01-28 08:29:06', '2020-01-28 00:45:47'),
(2, 'Mukesh', 'Kushwa', 'mukesh@gmail.com', 'MTIz', '1122334466', 'Mumbai', 0, '2020-01-28 09:21:38', '0000-00-00 00:00:00'),
(3, 'POOJA', 'PAWAR', 'pooja@gmail.com', 'MTIzNA==', '9850007574', 'pune', 0, '2020-02-17 08:18:12', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `employee_payment`
--

CREATE TABLE `employee_payment` (
  `ep_id` int(11) NOT NULL,
  `ep_em_id` int(11) NOT NULL,
  `ep_present_days` int(11) NOT NULL,
  `ep_daily_wages` double NOT NULL,
  `ep_status` int(11) NOT NULL DEFAULT '0',
  `ep_created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ep_updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee_payment`
--

INSERT INTO `employee_payment` (`ep_id`, `ep_em_id`, `ep_present_days`, `ep_daily_wages`, `ep_status`, `ep_created_at`, `ep_updated_at`) VALUES
(1, 3, 5, 50, 0, '2020-03-12 04:04:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `farmer_master`
--

CREATE TABLE `farmer_master` (
  `fm_id` int(11) NOT NULL,
  `fm_first_name` varchar(21) NOT NULL,
  `fm_last_name` varchar(21) NOT NULL,
  `fm_email` varchar(255) DEFAULT NULL,
  `fm_password` varchar(255) NOT NULL,
  `fm_mobile` varchar(15) NOT NULL,
  `fm_address` text,
  `fm_status` int(11) NOT NULL DEFAULT '0',
  `fm_created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fm_updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `farmer_master`
--

INSERT INTO `farmer_master` (`fm_id`, `fm_first_name`, `fm_last_name`, `fm_email`, `fm_password`, `fm_mobile`, `fm_address`, `fm_status`, `fm_created_at`, `fm_updated_at`) VALUES
(20205, 'Fahaddd', 'Mukadammm', 'fahad@gmail.commm', 'MTIzMTIzMTIz', '9988774455', 'Camppp', 1, '2020-01-03 17:24:06', '2020-01-03 23:48:27'),
(20206, 'Fahadd', 'Mukadamm', 'fahad1@gmail.comm', 'MTIzMTIz', '1234567891', 'Ratnagiri', 0, '2020-01-03 18:14:48', '2020-01-18 23:51:27'),
(20207, 'Aniket', 'Bhosle', 'aniket@gmail.com', 'MTIz', '5588558855', 'Wagholi', 0, '2020-01-03 18:19:35', '2020-01-03 23:49:35'),
(20208, 'Mukeshh', 'Kushwa', 'mukesh@gmail.comm', 'MTIzMw==', '4747474747', 'Rohaa', 1, '2020-01-03 18:34:37', '2020-01-18 19:51:14'),
(20209, 'ibrahim', 'mukadam', 'ibrahim@gmail.com', 'MTIz', '9404220309', 'mhapral', 0, '2020-01-25 19:49:41', '2020-01-25 11:49:41'),
(20210, 'Vishwa', 'taware', 'TEST@GMAIL.COM', 'MTIzNA==', '7744062398', 'pune', 0, '2020-02-17 07:51:24', '2020-02-17 13:21:24'),
(20214, 'abhi', 'tilekar', 'abhi@gmail.com', 'abhi', '9850075743', 'pune', 0, '2020-02-17 08:16:16', '2020-06-11 15:57:33'),
(20215, 'PRANITA', 'GIJJAR', 'pranita@gmail.com', 'cHJhbml0YQ==', '7071702323', 'pune', 0, '2020-03-09 13:32:51', '2020-03-09 19:02:51'),
(20216, 'vinit', 'sharma', 'vinit@gmail.com', 'MTIzNA==', '8600899893', 'pune', 0, '2020-09-14 12:26:55', '2020-09-14 17:56:55');

-- --------------------------------------------------------

--
-- Table structure for table `gate_keeper_master`
--

CREATE TABLE `gate_keeper_master` (
  `gk_id` int(11) NOT NULL,
  `gk_first_name` varchar(21) NOT NULL,
  `gk_last_name` varchar(21) NOT NULL,
  `gk_email` varchar(255) NOT NULL,
  `gk_password` varchar(255) NOT NULL,
  `gk_mobile` varchar(15) NOT NULL,
  `gk_address` text NOT NULL,
  `gk_status` int(11) NOT NULL DEFAULT '0',
  `gk_created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gk_updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gate_keeper_master`
--

INSERT INTO `gate_keeper_master` (`gk_id`, `gk_first_name`, `gk_last_name`, `gk_email`, `gk_password`, `gk_mobile`, `gk_address`, `gk_status`, `gk_created_at`, `gk_updated_at`) VALUES
(1, 'Virat', 'Kohli', 'gate@gmail.com', '1234', '4455668855', 'Mumbai', 0, '2020-02-09 04:58:37', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `gate_master`
--

CREATE TABLE `gate_master` (
  `gm_id` int(11) NOT NULL,
  `gm_vehicle_no` varchar(255) NOT NULL,
  `gm_description` text NOT NULL,
  `gm_quantity` int(11) NOT NULL,
  `gm_ward_entry` varchar(255) NOT NULL,
  `gm_status` int(11) NOT NULL DEFAULT '0',
  `gm_created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gm_updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gate_master`
--

INSERT INTO `gate_master` (`gm_id`, `gm_vehicle_no`, `gm_description`, `gm_quantity`, `gm_ward_entry`, `gm_status`, `gm_created_at`, `gm_updated_at`) VALUES
(1, 'Mh 12 CH 47477', 'TEst22', 455, 'OutWard', 0, '2020-02-09 07:48:22', '2020-02-09 13:50:37'),
(2, 'Mh 12 Br 1258', 'TEst2', 14, 'InWard', 1, '2020-02-09 07:49:10', '2020-02-09 13:29:19'),
(3, 'MH12QM2261', 'TEMPO WITH MILK CRATE', 15, 'OutWard', 0, '2020-02-17 10:47:26', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `hr_master`
--

CREATE TABLE `hr_master` (
  `hrm_id` int(11) NOT NULL,
  `hrm_first_name` varchar(21) NOT NULL,
  `hrm_last_name` varchar(21) NOT NULL,
  `hrm_email` varchar(255) NOT NULL,
  `hrm_password` varchar(255) NOT NULL,
  `hrm_mobile` varchar(15) NOT NULL,
  `hrm_address` text NOT NULL,
  `hrm_status` int(11) NOT NULL DEFAULT '0',
  `hrm_created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `hrm_updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hr_master`
--

INSERT INTO `hr_master` (`hrm_id`, `hrm_first_name`, `hrm_last_name`, `hrm_email`, `hrm_password`, `hrm_mobile`, `hrm_address`, `hrm_status`, `hrm_created_at`, `hrm_updated_at`) VALUES
(1, 'HR', 'HR', 'hr@gmail.com', 'hr', '1122334455', 'Pune', 0, '2020-01-28 07:42:23', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `milk_rate_master`
--

CREATE TABLE `milk_rate_master` (
  `mrm_id` int(11) NOT NULL,
  `mrm_snf` int(11) NOT NULL,
  `mrm_rate` double NOT NULL,
  `mrm_status` int(11) NOT NULL DEFAULT '0',
  `mrm_created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `mrm_updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `milk_rate_master`
--

INSERT INTO `milk_rate_master` (`mrm_id`, `mrm_snf`, `mrm_rate`, `mrm_status`, `mrm_created_at`, `mrm_updated_at`) VALUES
(1, 1, 11, 0, '2019-12-22 18:16:50', '2020-01-14 01:45:25'),
(3, 2, 15, 0, '2019-12-22 18:35:49', '2020-01-14 01:45:37'),
(4, 3, 19, 0, '2019-12-23 17:35:53', '2020-01-14 01:45:48'),
(5, 4, 38, 0, '2019-12-25 18:24:37', '2020-01-14 01:43:48'),
(6, 5, 40, 0, '2019-12-25 18:47:55', '2020-01-14 01:44:00'),
(7, 6, 42, 0, '2019-12-26 17:20:09', '2020-01-14 01:45:08'),
(8, 8, 44, 0, '2020-01-01 14:23:02', '2020-01-14 01:44:17'),
(9, 9, 46, 0, '2020-01-01 14:23:11', '2020-01-14 01:44:26'),
(11, 11, 50, 0, '2020-01-02 10:42:36', '2020-01-14 01:44:40'),
(15, 10, 15, 0, '2020-02-17 08:15:45', '2020-02-19 09:26:14');

-- --------------------------------------------------------

--
-- Table structure for table `procurement_master`
--

CREATE TABLE `procurement_master` (
  `pm_id` int(11) NOT NULL,
  `pm_first_name` varchar(21) NOT NULL,
  `pm_last_name` varchar(21) NOT NULL,
  `pm_email` varchar(55) DEFAULT NULL,
  `pm_password` varchar(255) NOT NULL,
  `pm_mobile` varchar(15) DEFAULT NULL,
  `pm_address` text,
  `pm_status` int(11) NOT NULL DEFAULT '0',
  `pm_created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `pm_updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `procurement_master`
--

INSERT INTO `procurement_master` (`pm_id`, `pm_first_name`, `pm_last_name`, `pm_email`, `pm_password`, `pm_mobile`, `pm_address`, `pm_status`, `pm_created_at`, `pm_updated_at`) VALUES
(1, 'admin', 'admin', 'admin@gmail.com', 'admin', '1234567891', 'Pune', 0, '2019-12-20 19:14:50', '2019-12-21 00:44:50');

-- --------------------------------------------------------

--
-- Table structure for table `product_master`
--

CREATE TABLE `product_master` (
  `prm_id` int(11) NOT NULL,
  `prm_name` varchar(255) NOT NULL,
  `prm_rate` double NOT NULL,
  `prm_status` int(11) NOT NULL DEFAULT '0',
  `prm_created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `prm_updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_master`
--

INSERT INTO `product_master` (`prm_id`, `prm_name`, `prm_rate`, `prm_status`, `prm_created_at`, `prm_updated_at`) VALUES
(1, 'Ghee', 70, 0, '2020-02-09 18:32:02', '2020-02-10 23:54:50'),
(2, 'PANNER', 50, 0, '2020-02-17 10:53:31', '0000-00-00 00:00:00'),
(3, 'ICE CREAM', 30, 0, '2020-02-17 10:56:28', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `raw_material_master`
--

CREATE TABLE `raw_material_master` (
  `rmm_id` int(11) NOT NULL,
  `rmm_description` text NOT NULL,
  `rmm_quantity` double NOT NULL,
  `rmm_status` int(11) NOT NULL DEFAULT '0',
  `rmm_created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `rmm_updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `raw_material_master`
--

INSERT INTO `raw_material_master` (`rmm_id`, `rmm_description`, `rmm_quantity`, `rmm_status`, `rmm_created_at`, `rmm_updated_at`) VALUES
(1, 'test', 12, 0, '2020-02-08 18:46:01', '2020-02-09 01:16:18'),
(2, 'test', 12, 0, '2020-02-08 18:48:39', '0000-00-00 00:00:00'),
(3, 'test1', 123, 1, '2020-02-08 18:49:25', '2020-02-09 00:49:09'),
(4, 'MILK POWDER QTY IN KG', 3, 0, '2020-02-17 10:44:37', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `sale_master`
--

CREATE TABLE `sale_master` (
  `sm_id` int(11) NOT NULL,
  `sm_cm_id` int(11) NOT NULL,
  `sm_prm_name` varchar(255) NOT NULL,
  `sm_prm_rate` double NOT NULL,
  `sm_quantity` int(11) NOT NULL,
  `sm_status` int(11) NOT NULL DEFAULT '0',
  `sm_created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sm_updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sale_master`
--

INSERT INTO `sale_master` (`sm_id`, `sm_cm_id`, `sm_prm_name`, `sm_prm_rate`, `sm_quantity`, `sm_status`, `sm_created_at`, `sm_updated_at`) VALUES
(1, 2, '1', 70, 7, 0, '2020-02-10 19:00:09', '0000-00-00 00:00:00'),
(2, 1, '1', 70, 50, 0, '2020-02-14 05:54:31', '0000-00-00 00:00:00'),
(3, 2, '3', 30, 5, 0, '2020-02-17 10:56:51', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `storage_master`
--

CREATE TABLE `storage_master` (
  `sm_id` int(11) NOT NULL,
  `sm_name` varchar(255) NOT NULL,
  `sm_capacity` double NOT NULL,
  `sm_available` double NOT NULL,
  `sm_milk_available` double NOT NULL,
  `sm_status` int(11) NOT NULL DEFAULT '0',
  `sm_created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sm_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `storage_master`
--

INSERT INTO `storage_master` (`sm_id`, `sm_name`, `sm_capacity`, `sm_available`, `sm_milk_available`, `sm_status`, `sm_created_at`, `sm_updated`) VALUES
(1, 'Tank 1', 10000, 0, 0, 1, '2020-01-04 14:50:39', '2020-01-13 21:52:42'),
(2, 'Tank 2', 5000, 3970, 1030, 0, '2020-01-04 14:53:36', '2020-02-17 08:16:31'),
(3, 'Tank 3', 2000, 2000, 0, 0, '2020-01-04 14:54:31', '2020-01-04 14:54:31'),
(4, 'Tank 4', 10000, 9877, 123, 0, '2020-01-04 14:57:29', '2020-02-16 12:51:52'),
(5, 'Tank 5', 1000, 850, 150, 0, '2020-01-04 15:31:11', '2020-02-17 08:13:15');

-- --------------------------------------------------------

--
-- Table structure for table `store_manager_master`
--

CREATE TABLE `store_manager_master` (
  `sms_id` int(11) NOT NULL,
  `sms_first_name` varchar(21) NOT NULL,
  `sms_last_name` varchar(21) NOT NULL,
  `sms_email` varchar(255) NOT NULL,
  `sms_password` varchar(255) NOT NULL,
  `sms_mobile` varchar(15) NOT NULL,
  `sms_address` text NOT NULL,
  `sms_status` int(11) NOT NULL DEFAULT '0',
  `sms_created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sms_updated_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `store_manager_master`
--

INSERT INTO `store_manager_master` (`sms_id`, `sms_first_name`, `sms_last_name`, `sms_email`, `sms_password`, `sms_mobile`, `sms_address`, `sms_status`, `sms_created_at`, `sms_updated_at`) VALUES
(1, 'Virat', 'Kholi', 'sms@gmail.com', '1234', '1122336655', 'Solapur', 0, '2020-02-05 17:50:03', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bill_farmer`
--
ALTER TABLE `bill_farmer`
  ADD PRIMARY KEY (`bf_id`),
  ADD KEY `bf_fm_id` (`bf_fm_id`),
  ADD KEY `bf_sm_id` (`bf_sm_id`);

--
-- Indexes for table `customer_master`
--
ALTER TABLE `customer_master`
  ADD PRIMARY KEY (`cm_id`);

--
-- Indexes for table `distributor_master`
--
ALTER TABLE `distributor_master`
  ADD PRIMARY KEY (`dm_id`);

--
-- Indexes for table `employee_leaves`
--
ALTER TABLE `employee_leaves`
  ADD PRIMARY KEY (`el_id`),
  ADD KEY `el_em_id` (`el_em_id`);

--
-- Indexes for table `employee_master`
--
ALTER TABLE `employee_master`
  ADD PRIMARY KEY (`em_id`);

--
-- Indexes for table `employee_payment`
--
ALTER TABLE `employee_payment`
  ADD PRIMARY KEY (`ep_id`),
  ADD KEY `ep_em_id` (`ep_em_id`);

--
-- Indexes for table `farmer_master`
--
ALTER TABLE `farmer_master`
  ADD PRIMARY KEY (`fm_id`);

--
-- Indexes for table `gate_keeper_master`
--
ALTER TABLE `gate_keeper_master`
  ADD PRIMARY KEY (`gk_id`);

--
-- Indexes for table `gate_master`
--
ALTER TABLE `gate_master`
  ADD PRIMARY KEY (`gm_id`);

--
-- Indexes for table `hr_master`
--
ALTER TABLE `hr_master`
  ADD PRIMARY KEY (`hrm_id`);

--
-- Indexes for table `milk_rate_master`
--
ALTER TABLE `milk_rate_master`
  ADD PRIMARY KEY (`mrm_id`);

--
-- Indexes for table `procurement_master`
--
ALTER TABLE `procurement_master`
  ADD PRIMARY KEY (`pm_id`);

--
-- Indexes for table `product_master`
--
ALTER TABLE `product_master`
  ADD PRIMARY KEY (`prm_id`);

--
-- Indexes for table `raw_material_master`
--
ALTER TABLE `raw_material_master`
  ADD PRIMARY KEY (`rmm_id`);

--
-- Indexes for table `sale_master`
--
ALTER TABLE `sale_master`
  ADD PRIMARY KEY (`sm_id`),
  ADD KEY `sm_cm_id` (`sm_cm_id`);

--
-- Indexes for table `storage_master`
--
ALTER TABLE `storage_master`
  ADD PRIMARY KEY (`sm_id`);

--
-- Indexes for table `store_manager_master`
--
ALTER TABLE `store_manager_master`
  ADD PRIMARY KEY (`sms_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bill_farmer`
--
ALTER TABLE `bill_farmer`
  MODIFY `bf_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `customer_master`
--
ALTER TABLE `customer_master`
  MODIFY `cm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `distributor_master`
--
ALTER TABLE `distributor_master`
  MODIFY `dm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `employee_leaves`
--
ALTER TABLE `employee_leaves`
  MODIFY `el_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `employee_master`
--
ALTER TABLE `employee_master`
  MODIFY `em_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `employee_payment`
--
ALTER TABLE `employee_payment`
  MODIFY `ep_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `farmer_master`
--
ALTER TABLE `farmer_master`
  MODIFY `fm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20217;

--
-- AUTO_INCREMENT for table `gate_keeper_master`
--
ALTER TABLE `gate_keeper_master`
  MODIFY `gk_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `gate_master`
--
ALTER TABLE `gate_master`
  MODIFY `gm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `hr_master`
--
ALTER TABLE `hr_master`
  MODIFY `hrm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `milk_rate_master`
--
ALTER TABLE `milk_rate_master`
  MODIFY `mrm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `procurement_master`
--
ALTER TABLE `procurement_master`
  MODIFY `pm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `product_master`
--
ALTER TABLE `product_master`
  MODIFY `prm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `raw_material_master`
--
ALTER TABLE `raw_material_master`
  MODIFY `rmm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sale_master`
--
ALTER TABLE `sale_master`
  MODIFY `sm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `storage_master`
--
ALTER TABLE `storage_master`
  MODIFY `sm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `store_manager_master`
--
ALTER TABLE `store_manager_master`
  MODIFY `sms_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bill_farmer`
--
ALTER TABLE `bill_farmer`
  ADD CONSTRAINT `bill_farmer_ibfk_1` FOREIGN KEY (`bf_sm_id`) REFERENCES `storage_master` (`sm_id`),
  ADD CONSTRAINT `bill_farmer_ibfk_2` FOREIGN KEY (`bf_fm_id`) REFERENCES `farmer_master` (`fm_id`);

--
-- Constraints for table `employee_leaves`
--
ALTER TABLE `employee_leaves`
  ADD CONSTRAINT `employee_leaves_ibfk_1` FOREIGN KEY (`el_em_id`) REFERENCES `employee_master` (`em_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
