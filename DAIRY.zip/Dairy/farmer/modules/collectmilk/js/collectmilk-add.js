


$(document).ready(function(e){

	var milkrate,sm_available;
 
	 $('#id_txt_cm_fm_first_name').typeahead({
	  source: function(query, result)
	  {
	   $.ajax({
	    url:"../php/fetch.php",
	    method:"POST",
	    data:{query:query},
	    dataType:"json",
	    success:function(data)
	    {
	     result($.map(data, function(item){
	     	console.log(item[2]);
	      // alert(item);
	      return item[0]+" "+item[1]+" "+item[2]+" "+item[3]+" "+"("+item[4]+")";
	     }));
	    }
	   })
	  }, afterSelect: function (data) {
        //print the data to developer tool's console
        console.log(data);
        }
	 });



       
        // $.ajax({
        //       type: 'POST',
        //       url: '../php/get-storage.php',
        //       data: {}        
        // })
        // .done(function(response){
        //   $("#id_bf_sm_id").html(response);
        // })
        // .fail(function(response) {
        //       console.log(response);
        // });  



        $.ajax({
              type: 'POST',
              url: '../php/get-snf.php',
              data: {}        
        })
        .done(function(response){
          $("#id_bf_mrm_snf").html(response);

        })
        .fail(function(response) {
              console.log(response);
        });




        $("#id_bf_mrm_snf").change(function(){
        	$.ajax({
              type: 'POST',
              url: '../php/get-milkrate-by-id.php',
              data: {mrm_id:$("#id_bf_mrm_snf").val()}        
	        })
	        .done(function(response){
	          $("#id_lbl_cm_mrm_rate").html(response);
	          milkrate = response;
	          calcAmount();
	        })
	        .fail(function(response) {
	              console.log(response);
	        });
		});


        

        $("#id_bf_sm_id").change(function(){
        	$.ajax({
              type: 'POST',
              url: '../php/get-storage-by-id.php',
              data: {sm_id:$("#id_bf_sm_id").val()}        
	        })
	        .done(function(response){
	          $("#id_lbl_cm_storage_avialability").html(response+' Litre');
	          sm_available = response;
	          // calcAmount();
	        })
	        .fail(function(response) {
	              console.log(response);
	        });
		});


		$( "#id_num_cm_milk" ).keyup(function() {

	        $("#id_lbl_cm_storage_avialability").html('');

			$.ajax({
              type: 'POST',
              url: '../php/get-storage-filter.php',
              data: {milk:$("#id_num_cm_milk").val()}        
	        })
	        .done(function(response){
	          $("#id_bf_sm_id").html(response);
	          calcAmount();
	        })
	        .fail(function(response) {
	              console.log(response);
	        });  

		  // calcAmount();
		});

		function calcAmount(){

			console.log("keypress");

			var milk = $("#id_num_cm_milk").val();

	          $("#id_lbl_cm_totalAmount").html(milk * milkrate);
		}

	localStorage.removeItem("sm_edit_details"); 
	$("#id_small_sm_name").hide(); 
	$("#id_small_sm_capacity").hide();                           

	$("#id_btnSaveData").click(function(e) {

		var bf_fm_id, bf_milk, bf_sm_id, bf_mrm_snf, bf_mrm_rate;

		bf_fm_id = $("#id_txt_cm_fm_first_name").val();
		bf_fm_id = bf_fm_id.split(' ')[0]; 
		bf_milk = $("#id_num_cm_milk").val();
		bf_sm_id = $("#id_bf_sm_id").val();
		bf_mrm_snf = $("#id_bf_mrm_snf").val();
		bf_mrm_rate = milkrate;
		
	    var nameRegex = /^[a-zA-Z ]{2,30}$/;
	    var numberRegex = /^[0-9]{1,10}$/;
	    var emailRegex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	    var mobileNumberRegex = /^\d{10}$/;
        var nameNumberRegex = /[^A-Za-z0-9 ]+/;
	 	if($('#id_txt_cm_fm_first_name').val() == undefined || $('#id_txt_cm_fm_first_name').val() == "")
      	{	
      		$("#id_small_cm_fm_first_name").html("Please Search Farmer Name");
      		$("#id_small_cm_fm_first_name").show().delay(4000).fadeOut();
      		$('#id_txt_cm_fm_first_name').focus();
      		return false;
      	} 
      	else if($('#id_num_cm_milk').val() == undefined || $('#id_num_cm_milk').val() == "")
      	{			
      		$("#id_small_cm_milk").html("Please Enter Milk in Litre");
      		$("#id_small_cm_milk").show().delay(4000).fadeOut();	      		
      		$('#id_num_cm_milk').focus();
      		return false;
      	}  
      	else if($('#id_bf_sm_id').val() == undefined || $('#id_bf_sm_id').val() == "")
      	{			
      		$("#id_small_cm_storage").html("Please Select Storage");
      		$("#id_small_cm_storage").show().delay(4000).fadeOut();	      		
      		$('#id_bf_sm_id').focus();
      		return false;
      	} 
      	else if($('#id_bf_mrm_snf').val() == undefined || $('#id_bf_mrm_snf').val() == "")
      	{			
      		$("#id_small_cm_mrm_snf").html("Please Select SNF");
      		$("#id_small_cm_mrm_snf").show().delay(4000).fadeOut();	      		
      		$('#id_bf_mrm_snf').focus();
      		return false;
      	} 		
		else
		{ 
		  sm_available = sm_available - bf_milk;
		  $.ajax({
		        type: 'POST',
		        url: '../php/collectmilk-add.php',
		        data: {bf_fm_id : bf_fm_id, bf_milk : bf_milk, bf_sm_id:bf_sm_id, bf_mrm_snf:bf_mrm_snf, bf_mrm_rate:bf_mrm_rate, sm_available:sm_available}
		   })
		  .done(function(response){ 
		  
		        if(response == 1){
		        alert("Milk Collected..!");

				location.reload();
		   }else{
		        alert(response);

		        
		        }
		   })
		   .fail(function(response) {

		   		console.log("Oop's Something went wrong..!");
		   		alert(response);
		   });
		   return false;
		}
	});


});