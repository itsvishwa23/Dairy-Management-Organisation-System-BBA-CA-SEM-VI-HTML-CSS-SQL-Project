<?php
session_start();
require '../../../../common/connection.php';

$fm_email=$_SESSION["pm_email"];

$i=0;
$sql="SELECT * FROM bill_farmer bf LEFT OUTER JOIN farmer_master fm ON bf.bf_fm_id = fm.fm_id LEFT OUTER JOIN storage_master sm on bf.bf_sm_id = sm.sm_id where fm.fm_email = '".$fm_email."'";
$result = $conn->query($sql);

$list = array();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		array_push($list,array(++$i,$row["bf_milk"]." Litre",$row["bf_mrm_snf"],"Rs.".$row["bf_mrm_rate"],"Rs.".$row["bf_milk"] * $row["bf_mrm_rate"],$row["bf_created_at"]));
    }
} else {
    echo "0 results";
}


$myJSON = json_encode($list);
echo $myJSON;
$conn->close();
?>