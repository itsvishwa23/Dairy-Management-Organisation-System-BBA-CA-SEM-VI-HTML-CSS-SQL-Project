<?php
session_start();
require '../../../../common/connection.php';
 
$bf_fm_id=$_POST["bf_fm_id"];
$bf_milk=$_POST["bf_milk"];
$bf_sm_id=$_POST["bf_sm_id"];
$bf_mrm_snf=$_POST["bf_mrm_snf"];
$bf_mrm_rate=$_POST["bf_mrm_rate"];
$sm_available=$_POST["sm_available"];

$sql = "INSERT bill_farmer(bf_fm_id,bf_milk,bf_sm_id,bf_mrm_snf,bf_mrm_rate) VALUES ('".$bf_fm_id."','".$bf_milk."','".$bf_sm_id."','".$bf_mrm_snf."','".$bf_mrm_rate."')";

$insert = $conn->query($sql);
if($insert == 1){

	$sql = "SELECT sm_milk_available from storage_master where sm_id='" .$bf_sm_id. "'";
	$result = $conn->query($sql);
	$row = $result->fetch_assoc();
	$sm_milk_available = $row["sm_milk_available"] + $bf_milk;

	$sql = "UPDATE storage_master SET sm_available='".$sm_available."',sm_milk_available='".$sm_milk_available."' WHERE sm_id = '".$bf_sm_id."' ";
	$result = $conn->query($sql);
	echo $result;
}			
$conn->close();
?>