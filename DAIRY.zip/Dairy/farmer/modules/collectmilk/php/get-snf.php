<?php
session_start();
require '../../../../common/connection.php';
$sqlchk = "SELECT * FROM milk_rate_master where mrm_status = 0";
$result = $conn->query($sqlchk);

			if ($result->num_rows > 1) {
				echo '<option selected disabled>--select--</option>';
    while($row = $result->fetch_assoc()) {

    	echo '<option value='.$row["mrm_id"].'>'.$row["mrm_snf"].'</option>';
    }
} else {
    echo "0 results";
}
$conn->close();
?>