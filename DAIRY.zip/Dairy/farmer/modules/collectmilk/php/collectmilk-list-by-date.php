<?php
session_start();
require '../../../../common/connection.php';


 
$bf_created_at=$_POST["bf_created_at"];
$fm_email=$_SESSION["pm_email"];
$i=0;
$sql="SELECT bf.bf_milk,bf.bf_mrm_snf,bf.bf_mrm_rate,bf.bf_created_at FROM bill_farmer bf LEFT OUTER JOIN farmer_master fm ON bf.bf_fm_id = fm.fm_id WHERE Date(bf.bf_created_at) = '".$bf_created_at."' and fm.fm_email = '".$fm_email."'";
$result = $conn->query($sql);

$list = array();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		array_push($list,array(++$i,$row["bf_milk"]." Litre",$row["bf_mrm_snf"],"Rs.".$row["bf_mrm_rate"],"Rs.".$row["bf_milk"] * $row["bf_mrm_rate"],$row["bf_created_at"]));
    }
    $myJSON = json_encode($list);
	echo $myJSON;
} else {
    echo "0 results";
}



$conn->close();
?>