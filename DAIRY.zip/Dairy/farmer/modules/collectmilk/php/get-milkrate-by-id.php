<?php
session_start();

$mrm_id=$_POST["mrm_id"];
require '../../../../common/connection.php';
$sqlchk = "SELECT mrm_rate FROM milk_rate_master where mrm_id = $mrm_id";
$result = $conn->query($sqlchk);

			if ($result->num_rows == 1) {
				$row = $result->fetch_assoc();
				echo $row["mrm_rate"];
			}
			else{
				echo "0";
			}
$conn->close();
?>