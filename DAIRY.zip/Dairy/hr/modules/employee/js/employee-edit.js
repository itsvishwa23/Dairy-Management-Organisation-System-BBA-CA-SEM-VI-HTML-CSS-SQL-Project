$(document).ready(function(e){

  if (localStorage.getItem("em_edit_details") === null) {
    alert("Invalid Action");
    window.location="employee-list.html";
  }



  var json = localStorage.getItem("em_edit_details");
  var em_edit_details = JSON.parse(json);
  var em_id = em_edit_details.em_id;
  var em_first_name = em_edit_details.em_first_name;
  var em_last_name = em_edit_details.em_last_name;
  var em_email = em_edit_details.em_email;
  var em_password = em_edit_details.em_password;
  var em_mobile = em_edit_details.em_mobile;
  var em_address = em_edit_details.em_address;
  var em_created_at = em_edit_details.em_created_at;


  $("#id_lbl_employeeId").html(em_id);
  $("#id_txt_em_firstName").val(em_first_name);
  $('#id_txt_em_lastName').val(em_last_name);
  $("#id_txt_em_email").val(em_email);
  $('#id_txt_em_password').val(em_password);
  $("#id_txt_em_mobile").val(em_mobile);
  $("#id_txtArea_em_address").val(em_address);



    $("#id_btnUpdateData").click(function(e) {


      var nameRegex = /^[a-zA-Z ]{2,30}$/;
      var numberRegex = /^[0-9]{1,10}$/;
      var emailRegex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      var mobileNumberRegex = /^\d{10}$/;

    
    var em_first_name,em_last_name,em_email,em_password,em_mobile,em_address;
    em_first_name=$("#id_txt_em_firstName").val();
    em_last_name=$("#id_txt_em_lastName").val();
    em_email=$("#id_txt_em_email").val();
    em_password=$("#id_txt_em_password").val();
    em_mobile=$("#id_txt_em_mobile").val();
    em_address=$("#id_txtArea_em_address").val();

    if($('#id_txt_em_firstName').val() == undefined || $('#id_txt_em_firstName').val() == "")
        { 
          $("#id_small_em_firstName").html("Please Enter First Name");
          $("#id_small_em_firstName").show().delay(4000).fadeOut();
          $('#id_txt_em_firstName').focus();
          return false;
        } 
        else if($('#id_txt_em_lastName').val() == undefined || $('#id_txt_em_lastName').val() == "")
        {     
          $("#id_small_em_lastName").html("Please Enter Last Name");
          $("#id_small_em_lastName").show().delay(4000).fadeOut();            
          $('#id_txt_em_lastName').focus();
          return false;
        } 
        else if($('#id_txt_em_email').val() == undefined || $('#id_txt_em_email').val() == "")
        {     
          $("#id_small_em_email").html("Please Enter Email");
          $("#id_small_em_email").show().delay(4000).fadeOut();
          $('#id_txt_em_email').focus();
          return false;
        } 
        else if($('#id_txt_em_password').val() == undefined || $('#id_txt_em_password').val() == "")
        {     
          $("#id_small_em_password").html("Please Enter Password");
          $("#id_small_em_password").show().delay(4000).fadeOut();
          $('#id_txt_em_password').focus();
          return false;
        }  
        else if($('#id_txt_em_mobile').val() == undefined || $('#id_txt_em_mobile').val() == "")
        {     
          $("#id_small_em_mobile").html("Please Enter Mobile");
          $("#id_small_em_mobile").show().delay(4000).fadeOut();
          $('#id_txt_em_mobile').focus();
          return false;
        }  
        else if($('#id_txt_em_password').val() == undefined || $('#id_txt_em_password').val() == "")
        {     
          $("#id_small_em_password").html("Please Enter Password");
          $("#id_small_em_password").show().delay(4000).fadeOut();
          $('#id_txt_em_password').focus();
          return false;
        }          
        else if($('#id_txtArea_em_address').val() == undefined || $('#id_txtArea_em_address').val() == "")
        {     
          $("#id_small_em_address").html("Please Enter Address");
          $("#id_small_em_address").show().delay(4000).fadeOut();
          $('#id_txtArea_em_address').focus();
          return false;
        }         
        else if(!nameRegex.test($('#id_txt_em_firstName').val())){    
          $("#id_small_em_firstName").html("Please Enter valid Name");
          $("#id_small_em_firstName").show().delay(4000).fadeOut();
          $('#id_txt_em_firstName').focus();
          return false;
        }         
        else if(!nameRegex.test($('#id_txt_em_lastName').val())){   
          $("#id_small_em_lastName").html("Please Enter valid Name");
          $("#id_small_em_lastName").show().delay(4000).fadeOut();
          $('#id_txt_em_lastName').focus();
          return false;
        }         
        else if(!emailRegex.test($('#id_txt_em_email').val())){   
          $("#id_small_em_email").html("Please Enter valid Email");
          $("#id_small_em_email").show().delay(4000).fadeOut();
          $('#id_txt_em_email').focus();
          return false;
        }         
        else if(!mobileNumberRegex.test($('#id_txt_em_mobile').val())){   
          $("#id_small_em_mobile").html("Please Enter valid Mobile");
          $("#id_small_em_mobile").show().delay(4000).fadeOut();
          $('#id_txt_em_mobile').focus();
          return false;
        }     
    else
    {
      var data = {em_id : em_id, em_first_name : em_first_name, em_last_name : em_last_name, em_email : em_email, em_password : em_password, em_mobile : em_mobile, em_address : em_address};        
      $.ajax({
            type: 'POST',
            url: '../php/employee-edit.php',
            data: data
       })
      .done(function(response){ 
      
            if(response>0){

              localStorage.removeItem("em_edit_details");              
              alert("Employee Updated..!");
              window.location="employee-list.html";
              
            }
            else{
              alert("Employee not Updated -(:");
            
            }

       })
       .fail(function(response) {

          console.log("Oop's Something went wrong..!");
          alert(response);
       });
       return false;
    }
  });

    $("#id_back").click(function(e) {
      window.location="employee-list.html";
    });



});