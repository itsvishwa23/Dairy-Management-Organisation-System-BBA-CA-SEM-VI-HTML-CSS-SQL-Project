$(document).ready(function(e){

  localStorage.removeItem("em_edit_details");              

	$.ajax({
          type: 'POST',
          url: '../php/employee-list.php'
          
  	})
  .done(function(data){ 
    
    var dataSet=JSON.parse(data);
    var dataSet2 = [["Tiger Nixon","System Architect","Edinburgh"],
      ["Garrett Winters","Accountant","Tokyo"],
      ["Ashton Cox","Junior Technical Author","San Francisco"]];

    $('#id_list').DataTable( {
        data: dataSet,
        columns: [
            {"className": "dt-center", title: "SR NO" },
            {"className": "dt-center", title: "Employee Id" },
            {"className": "dt-center", title: "First Name" },
            {"className": "dt-center", title: "Last Name" },
            {"className": "dt-center", title: "Email" },
            {"className": "dt-center", title: "Password" },
            {"className": "dt-center", title: "Mobile" },
            {"className": "dt-center", title: "Address" },
            {"className": "dt-center", title: "Joining Date" },
            {"className": "dt-center", title: "Action" }
        ]
    } );
  })
  .fail(function(data) {
    alert(data);
  });  

  $("#id_list").on("click", ".fa-pencil-square-o", (function (ev){
    
    
    
    var em_id,em_first_name,em_last_name,em_email,em_password,em_mobile,em_address,em_created_at;
    em_id = $(this).parent().parent().children().children(".em_id").html();
    em_first_name = $(this).parent().parent().children().children(".em_first_name").html();
    em_last_name = $(this).parent().parent().children().children(".em_last_name").html();
    em_email = $(this).parent().parent().children().children(".em_email").html();
    em_password = $(this).parent().parent().children().children(".em_password").html();
    em_mobile = $(this).parent().parent().children().children(".em_mobile").html();
    em_address = $(this).parent().parent().children().children(".em_address").html();
    em_created_at = $(this).parent().parent().children().children(".em_created_at").html();
    
    
    var em_edit_details = { "em_id" : em_id, "em_first_name" : em_first_name, "em_last_name" : em_last_name, "em_email" : em_email, "em_password" : em_password, "em_mobile" : em_mobile, "em_address" : em_address, "em_created_at" : em_created_at};
    var myJSON = JSON.stringify(em_edit_details);    
    localStorage.setItem("em_edit_details", myJSON);

    if (localStorage.getItem("em_edit_details") != null) {
	  window.location="employee-edit.html";
	}
    }));



  $("#id_list").on("click", ".fa-trash-o", (function (ev){
    
    
    
    var em_id;
    em_id = $(this).parent().parent().children().children(".em_id").html();

    if (em_id != null || em_id !='' || em_id !=undefined) {
    	if (confirm("Are you sure want to delete this Employee?")) {

    
			    $.ajax({
			      type: 'POST',
			      url: '../php/employee-delete.php',
			      data: {em_id:em_id}
			    })
			    .done(function(data){
			    	alert(data); 
			    	location.reload();			      
			    })
			    .fail(function(data) {
			      alert(data);
			    });
		}
    }
    else{
    	alert("Invalid Action..!");
    }
    }));



});