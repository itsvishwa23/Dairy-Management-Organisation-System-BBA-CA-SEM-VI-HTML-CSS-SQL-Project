<?php
session_start();
require '../../../../common/connection.php';


$em_first_name=$_POST["em_first_name"];
$em_last_name=$_POST["em_last_name"];
$em_email=$_POST["em_email"];
// $em_password=MD5($_POST["em_password"]);
$em_password=base64_encode($_POST["em_password"]);
$em_mobile=$_POST["em_mobile"];
$em_address=$_POST["em_address"];



$sqlchk = "SELECT em_mobile from employee_master where em_mobile='" .$em_mobile. "'";
$result = $conn->query($sqlchk);

			if ($result->num_rows > 0) {
				echo "This is Existing Employee..!";
			}
			else{
					$sql = "INSERT employee_master(em_first_name,em_last_name,em_email,em_password,em_mobile,em_address) VALUES ('".$em_first_name."','".$em_last_name."','".$em_email."','".$em_password."','".$em_mobile."','".$em_address."')";
					$insert = $conn->query($sql);
					if($insert)
						echo "ok";
					else
						echo "not ok";
			}
$conn->close();
?>