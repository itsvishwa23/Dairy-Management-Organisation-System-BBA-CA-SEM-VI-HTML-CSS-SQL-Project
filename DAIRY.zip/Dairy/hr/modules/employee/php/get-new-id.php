<?php
session_start();
require '../../../../common/connection.php';
$sqlchk = "SELECT em_id FROM employee_master ORDER BY em_id DESC LIMIT 1";
$result = $conn->query($sqlchk);

			if ($result->num_rows == 1) {
				$row = $result->fetch_assoc();
				echo $row["em_id"];
			}
			else{
				echo "0";
			}
$conn->close();
?>