<?php
session_start();
require '../../../../common/connection.php';

$em_id=$_POST["em_id"];
$em_first_name=$_POST["em_first_name"];
$em_last_name=$_POST["em_last_name"];
$em_email=$_POST["em_email"];
$em_password=base64_encode($_POST["em_password"]);
$em_mobile=$_POST["em_mobile"];
$em_address=$_POST["em_address"];


$sql = "UPDATE employee_master SET em_first_name='".$em_first_name."',em_last_name='".$em_last_name."',em_email='".$em_email."',em_password='".$em_password."',em_mobile='".$em_mobile."',em_address='".$em_address."' WHERE em_id = '".$em_id."' ";
$result = $conn->query($sql);
echo $result;

$conn->close();

?>

