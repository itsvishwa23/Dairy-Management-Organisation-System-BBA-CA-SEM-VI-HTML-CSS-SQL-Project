<?php
session_start();
require '../../../../common/connection.php';

$em_id = $_POST['em_id'];

$sql = "UPDATE employee_master SET em_status=1 WHERE em_id = $em_id ";
$result = $conn->query($sql);

if($result){
	echo "Employee Deleted";
}
else{
	echo "Employee Not Deleted";
}

$conn->close();

?>

