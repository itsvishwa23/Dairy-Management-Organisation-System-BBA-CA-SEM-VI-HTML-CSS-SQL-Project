<?php
session_start();
require '../../../../common/connection.php';

$i=0;

$sqlCount="SELECT count(*) as total from employee_master";
$result = $conn->query($sqlCount);
$data=$result->fetch_assoc();
$count=$data['total'];

$sql="select * from employee_master where em_status = 0";
$result = $conn->query($sql);

$list = array();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		array_push($list,array(++$i,$row["em_id"]."<span class='em_id' style='display:none;'>".$row["em_id"]."</span>",$row["em_first_name"]."<span class='em_first_name' style='display:none;'>".$row["em_first_name"]."</span>",$row["em_last_name"]."<span class='em_last_name' style='display:none;'>".$row["em_last_name"]."</span>",$row["em_email"]."<span class='em_email' style='display:none;'>".$row["em_email"]."</span>",base64_decode($row["em_password"])."<span class='em_password' style='display:none;'>".base64_decode($row["em_password"])."</span>",$row["em_mobile"]."<span class='em_mobile' style='display:none;'>".$row["em_mobile"]."</span>",$row["em_address"]."<span class='em_address' style='display:none;'>".$row["em_address"]."</span>",$row["em_created_at"]."<span class='em_created_at' style='display:none;'>".$row["em_created_at"]."</span>","<i style='cursor:pointer;' class='fa fa-pencil-square-o' ></i> &nbsp; <i style='cursor:pointer;' class='fa fa-trash-o'></i>"));
    }
} else {
    echo "0 results";
}


$myJSON = json_encode($list);
echo $myJSON;
$conn->close();
?>