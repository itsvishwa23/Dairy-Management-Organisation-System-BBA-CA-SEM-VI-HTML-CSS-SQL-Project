<?php
session_start();
require '../../../../common/connection.php';

$i=0;
$sql="SELECT * FROM employee_master em LEFT OUTER JOIN employee_payment ep ON em.em_id = ep.ep_em_id LEFT OUTER JOIN employee_leaves el ON em.em_id = el.el_em_id WHERE el_payment_status = 'paid'";
$result = $conn->query($sql);

$list = array();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		// array_push($list,array(++$i,$row["ep_id"]."<span class='ep_id' style='display:none;'>".$row["ep_id"]."</span>",$row["em_first_name"]."<span class='em_first_name' style='display:none;'>".$row["em_first_name"]."</span>",$row["em_last_name"]."<span class='em_last_name' style='display:none;'>".$row["em_last_name"]."</span>",$row["em_email"]."<span class='em_email' style='display:none;'>".$row["em_email"]."</span>",$row["em_mobile"]."<span class='em_mobile' style='display:none;'>".$row["em_mobile"]."</span>",$row["em_address"]."<span class='em_address' style='display:none;'>".$row["em_address"]."</span>",$row["ep_present_days"]."<span class='ep_present_days' style='display:none;'>".$row["ep_present_days"]."</span>",$row["ep_daily_wages"]."<span class='ep_daily_wages' style='display:none;'>".$row["ep_daily_wages"]."</span>",$row["ep_present_days"] * $row["ep_daily_wages"],$row["ep_created_at"]."<span class='ep_created_at' style='display:none;'>".$row["ep_created_at"]."</span>","<i style='cursor:pointer;' class='fa fa-pencil-square-o' ></i> &nbsp; <i style='cursor:pointer;' class='fa fa-trash-o'></i>"));


		array_push($list,array(++$i,$row["ep_id"],$row["em_first_name"],$row["em_last_name"],$row["em_email"],$row["em_mobile"],$row["em_address"],$row["ep_present_days"],$row["ep_daily_wages"],$row["ep_present_days"] * $row["ep_daily_wages"],$row["ep_created_at"],"<i style='cursor:pointer;' class='fa fa-pencil-square-o' ></i> &nbsp; <i style='cursor:pointer;' class='fa fa-trash-o'></i>"));
    }
} else {
    echo "0 results";
}


$myJSON = json_encode($list);
echo $myJSON;
$conn->close();
?>