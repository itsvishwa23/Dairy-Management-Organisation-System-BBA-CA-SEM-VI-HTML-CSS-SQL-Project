$(document).ready(function(e){

  var dataSet,columns;

  localStorage.removeItem("ep_edit_details");              

	$.ajax({
          type: 'POST',
          url: '../php/employeepayment-list.php'
          
  	})
  .done(function(data){ 
    
    dataSet=JSON.parse(data);
    $('#id_list').DataTable( {
        data: dataSet,
        columns: [
            {"className": "dt-center", title: "SR NO" },
            {"className": "dt-center", title: "EmployeePayment Id" },
            {"className": "dt-center", title: "First Name" },
            {"className": "dt-center", title: "Last Name" },
            {"className": "dt-center", title: "Email" },
            {"className": "dt-center", title: "Mobile" },
            {"className": "dt-center", title: "Address" },
            {"className": "dt-center", title: "Present Days" },
            {"className": "dt-center", title: "Daily Wages" },
            {"className": "dt-center", title: "Paid Amount" },
            {"className": "dt-center", title: "Date" },
            // {"className": "dt-center", title: "Action" }
        ],
        dom: 'lBfrtip',
        buttons: [

                { extend: 'pdf', className: 'btn btn-primary glyphicon glyphicon-file' }
            // 'pdf'
        ]
        // buttons: [
        //     {
        //         extend: 'pdf',
        //         customize: function ( win ) {
        //             $(win.document.body)
        //                 .css( 'font-size', '10pt' )
        //                 .prepend(
        //                     '<img src="http://datatables.net/media/images/logo-fade.png" style="position:absolute; top:0; left:0;" />'
        //                 );
 
        //             $(win.document.body).find( 'table' )
        //                 .addClass( 'compact' )
        //                 .css( 'font-size', 'inherit' );
        //         }
        //     }
        // ]
        // buttons: [
        //     'copy', 'csv', 'excel', 'pdf', 'print'
        // ]
    } );
  })
  .fail(function(data) {
    alert(data);
  }); 



 

  









  $("#id_list").on("click", ".fa-pencil-square-o", (function (ev){
    
    var ep_id,em_first_name,em_last_name,em_address,em_mobile,ep_present_days,ep_daily_wages;
    ep_id = $(this).parent().parent().children().children(".ep_id").html();
    em_first_name = $(this).parent().parent().children().children(".em_first_name").html();
    em_last_name = $(this).parent().parent().children().children(".em_last_name").html();
    em_address = $(this).parent().parent().children().children(".em_address").html();
    em_mobile = $(this).parent().parent().children().children(".em_mobile").html();
    ep_present_days = $(this).parent().parent().children().children(".ep_present_days").html();
    ep_daily_wages = $(this).parent().parent().children().children(".ep_daily_wages").html();
    
    var ep_edit_details = { "ep_id" : ep_id, "em_first_name" : em_first_name, "em_last_name" : em_last_name, em_address : em_address, "em_mobile" : em_mobile, ep_present_days : ep_present_days, "ep_daily_wages" : ep_daily_wages};
    var myJSON = JSON.stringify(ep_edit_details);    
    localStorage.setItem("ep_edit_details", myJSON);

    if (localStorage.getItem("ep_edit_details") != null) {
	  window.location="employeepayment-edit.html";
	}
    }));



  $("#id_list").on("click", ".fa-trash-o", (function (ev){
    
    
    
    var ep_id;
    ep_id = $(this).parent().parent().children().children(".ep_id").html();

    if (ep_id != null || ep_id !='' || ep_id !=undefined) {
    	if (confirm("Are you sure want to delete this EmployeePayment?")) {

    
			    $.ajax({
			      type: 'POST',
			      url: '../php/employeepayment-delete.php',
			      data: {ep_id:ep_id}
			    })
			    .done(function(data){
			    	alert(data); 
			    	location.reload();			      
			    })
			    .fail(function(data) {
			      alert(data);
			    });
		}
    }
    else{
    	alert("Invalid Action..!");
    }
    }));



});