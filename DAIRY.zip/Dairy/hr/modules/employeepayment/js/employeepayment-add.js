


$(document).ready(function(e){

	var startDay,endDay,date1,date2,presentDays,el_em_id;
 
	 $('#id_txt_ep_em_first_name').typeahead({
	  source: function(query, result)
	  {
	   $.ajax({
	    url:"../php/fetch.php",
	    method:"POST",
	    data:{query:query},
	    dataType:"json",
	    success:function(data)
	    {
	     result($.map(data, function(item){
	     	console.log(item[2]);
	      // alert(item);
	      return item[0]+" "+item[1]+" "+item[2]+" "+item[3]+" "+"("+item[4]+")";
	     }));
	    }
	   })
	  }, afterSelect: function (data) {
        //print the data to developer tool's console
        console.log(data);
        }
	 });



       
        // $.ajax({
        //       type: 'POST',
        //       url: '../php/get-storage.php',
        //       data: {}        
        // })
        // .done(function(response){
        //   $("#id_bf_sm_id").html(response);
        // })
        // .fail(function(response) {
        //       console.log(response);
        // });  



        // $.ajax({
        //       type: 'POST',
        //       url: '../php/get-snf.php',
        //       data: {}        
        // })
        // .done(function(response){
        //   $("#id_bf_mrm_snf").html(response);

        // })
        // .fail(function(response) {
        //       console.log(response);
        // });




  //       $("#id_bf_mrm_snf").change(function(){
  //       	$.ajax({
  //             type: 'POST',
  //             url: '../php/get-milkrate-by-id.php',
  //             data: {mrm_id:$("#id_bf_mrm_snf").val()}        
	 //        })
	 //        .done(function(response){
	 //          $("#id_lbl_cm_mrm_rate").html(response);
	 //          milkrate = response;
	 //          calcAmount();
	 //        })
	 //        .fail(function(response) {
	 //              console.log(response);
	 //        });
		// });


        

        $("#id_date_ep_start_date").change(function(){

        	calcAmount();
		});

		$("#id_date_ep_end_date").change(function(){

			calcAmount();
		});


		$( "#id_txt_ep_daily_wages" ).keyup(function() {

			calcTotalAmount();
		});

		function calcAmount(){



		  date1 = new Date($('#id_date_ep_start_date').val());
		  date2 = new Date($('#id_date_ep_end_date').val());

			var Difference_In_Time = date2.getTime() - date1.getTime(); 
			Difference_In_Time = Difference_In_Time / (1000 * 3600 * 24);
			Difference_In_Time = Difference_In_Time + 1;
		  	el_em_id = $("#id_txt_ep_em_first_name").val();
			el_em_id = el_em_id.split(' ')[0]; 

			var startDate = $("#id_date_ep_start_date").val(); 
			var endDate= $("#id_date_ep_end_date").val();

		  	$.ajax({
              type: 'POST',
              url: '../php/get-number-of-leaves.php',
              data: {el_em_id : el_em_id, startDate : startDate, endDate : endDate}        
	        })
	        .done(function(response){
	        	// alert(response);
	        	if(response == "This Employee Payment has been already Paid"){
	        		presentDays = response;
	        		$("#id_lbl_ep_present_days").html(response);	        	
	        	}
	        	else{
	        	presentDays = parseInt(Difference_In_Time)  - parseInt(response);
	          	$("#id_lbl_ep_present_days").html(presentDays);

	        	}
	        })
	        .fail(function(response) {
	              console.log(response);
	        });
		}

		function calcTotalAmount(){
			var dailyWages = $("#id_txt_ep_daily_wages").val();
			var totalAmount = presentDays * dailyWages;				        	
	        $("#id_lbl_ep_totalAmount").html(totalAmount);

		}

	localStorage.removeItem("sm_edit_details"); 
	$("#id_small_sm_name").hide(); 
	$("#id_small_sm_capacity").hide();                           

	$("#id_btnSaveData").click(function(e) {

		

		if(presentDays == "This Employee Payment has been already Paid"){
			alert(presentDays);
			return false;
		}
		else{

		var ep_daily_wages,startDate,endDate;
		startDate = $("#id_date_ep_start_date").val(); 
		var endDate= $("#id_date_ep_end_date").val();
		ep_daily_wages = $("#id_txt_ep_daily_wages").val();
		
	    var nameRegex = /^[a-zA-Z ]{2,30}$/;
	    var numberRegex = /^[0-9]{1,10}$/;
	    var emailRegex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	    var mobileNumberRegex = /^\d{10}$/;
        var nameNumberRegex = /[^A-Za-z0-9 ]+/;
	 	if($('#id_txt_ep_em_first_name').val() == undefined || $('#id_txt_ep_em_first_name').val() == "")
      	{	
      		$("#id_small_ep_em_first_name").html("Please Search Employee Name");
      		$("#id_small_ep_em_first_name").show().delay(4000).fadeOut();
      		$('#id_txt_ep_em_first_name').focus();
      		return false;
      	} 
      	else if($('#id_date_ep_start_date').val() == undefined || $('#id_date_ep_start_date').val() == "")
      	{			
      		$("#id_small_ep_start_date").html("Please Select Start Day");
      		$("#id_small_ep_start_date").show().delay(4000).fadeOut();	      		
      		$('#id_date_ep_start_date').focus();
      		return false;
      	}  
      	else if($('#id_date_ep_end_date').val() == undefined || $('#id_date_ep_end_date').val() == "")
      	{			
      		$("#id_small_ep_end_date").html("Please Select End Day");
      		$("#id_small_ep_end_date").show().delay(4000).fadeOut();	      		
      		$('#id_date_ep_end_date').focus();
      		return false;
      	} 
      	else if($('#id_txt_ep_daily_wages').val() == undefined || $('#id_txt_ep_daily_wages').val() == "")
      	{			
      		$("#id_small_ep_daily_wages").html("Please Enter Daily Wages Amount");
      		$("#id_small_ep_daily_wages").show().delay(4000).fadeOut();	      		
      		$('#id_txt_ep_daily_wages').focus();
      		return false;
      	} 		
		else
		{ 
		  $.ajax({
		        type: 'POST',
		        url: '../php/employeepayment-add.php',
		        data: {ep_em_id : el_em_id, ep_present_days : presentDays, ep_daily_wages:ep_daily_wages,startDate : startDate, endDate : endDate}
		   })
		  .done(function(response){ 
		  
		        if(response == 1){
		        alert("Payment Succeeded..!");
				

				location.reload();
		   }else{
		        alert(response);

		        
		        }
		   })
		   .fail(function(response) {

		   		console.log("Oop's Something went wrong..!");
		   		alert(response);
		   });
		   return false;
		}

		}
	});


});