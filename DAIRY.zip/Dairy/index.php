<?php
session_start();
// require 'connection.php';

if(!isset($_SESSION["role"])){	
	header("Location: login.html");
}
else{
	
	if($_SESSION["role"] == "Procurement"){
		header("Location: procurement/");
	}
	else if($_SESSION["role"] == "Farmer"){
		header("Location: farmer/");
	}
}






	// else {
	
// 	$sql = "SELECT firstname, lastname FROM customer where email='" . $_SESSION["username"] . "'";
// 	$result = $conn->query($sql);

// 	if ($result->num_rows > 0) {
// 		 while($row = $result->fetch_assoc()) {
// 			echo $row["firstname"] ." ". $row["lastname"];
// 		 }
// }
// else
// {
// 	echo "Username and password did not matched";
// }
// }
// $conn->close();
?>